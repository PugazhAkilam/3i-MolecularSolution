import React, { useState, useEffect } from 'react';
import { Box, Stack, Tabs, Tab } from '@mui/material';
import { DataGrid } from '@mui/x-data-grid';
import Swal from 'sweetalert2';

// Import custom components and services
import FilterControls from '../Table/FilterControls';
import { getColumnsForSourceType } from '../Table/tableColumns';
import { fetchBookings, fetchMyBookings, updateQueryStatus ,fetchFlightBookingCities,fetchHotelBookingRooms} from '../../service/bookingService';
import Dialog from '@mui/material/Dialog';
import DialogTitle from '@mui/material/DialogTitle';
import DialogContent from '@mui/material/DialogContent';
import DialogActions from '@mui/material/DialogActions';
import Button from '@mui/material/Button';

const FormTable = () => {
  const [activeTab, setActiveTab] = useState(0); // 0 for All Bookings, 1 for My Bookings
  const [bookingType, setBookingType] = useState('all');
  const [queryByUserCode, setQueryByUserCode] = useState('');
  const [startDate, setStartDate] = useState(null);
  const [endDate, setEndDate] = useState(null);
  const [searchQuery, setSearchQuery] = useState('');
  const [rows, setRows] = useState([]);
  const [loading, setLoading] = useState(false);
  const [hasInProcessQuery, setHasInProcessQuery] = useState(false);
  const [dialogOpen, setDialogOpen] = useState(false);
const [flightCities, setFlightCities] = useState([]);
const [selectedBookingId, setSelectedBookingId] = useState(null);
const [hotelRooms, setHotelRooms] = useState([]);
const [dialogType, setDialogType] = useState(''); // "Flight" or "Hotel"

  const handleAddToQuery = async (rowData) => {
    try {
      const response = await updateQueryStatus(rowData, 'IN PROGRESS');
      
      if (response.data.success) {
        console.log('Query status updated successfully');
        // Optionally refresh data
        fetchBookingsData();
      }
    } catch (error) {
      console.error('Error updating query status:', error);
      
      const msg = error.response?.data?.message || 'Something went wrong';
      
      Swal.fire({
        icon: 'error',
        title: 'Update Failed',
        text: msg,
        confirmButtonColor: '#d33'
      });
    }
  };
   console.log('flightCities:', flightCities);
   
   const handleOpenDialogBox = async (rowData) => {
    try {
      console.log('Opening dialog box for row:', rowData);
  
      setSelectedBookingId(rowData.BookingId);
  
      if (rowData.SourceType === 'Flight') {
        setDialogType('Flight');
        const response = await fetchFlightBookingCities(rowData.BookingId);
        if (Array.isArray(response.data)) {
          setFlightCities(response.data);
        } else {
          setFlightCities([]);
        }
      } else if (rowData.SourceType === 'Hotel') {
        setDialogType('Hotel');
        const response = await fetchHotelBookingRooms(rowData.BookingId);
        if (Array.isArray(response.data)) {
          setHotelRooms(response.data);
        } else {
          setHotelRooms([]);
        }
      } else {
        setDialogType('');
        setFlightCities([]);
        setHotelRooms([]);
      }
  
      setDialogOpen(true);
    } catch (error) {
      console.error('Error fetching booking details:', error);
      setFlightCities([]);
      setHotelRooms([]);
      setDialogOpen(true); // Open anyway to show error/empty
    }
  };
  
  

  const fetchBookingsData = async () => {
    try {
      setLoading(true);
      
      // Choose which API to call based on active tab
      const fetchFunction = activeTab === 0 ? fetchBookings : fetchMyBookings;
      
      const data = await fetchFunction({
        sourceType: bookingType === 'all' ? undefined : bookingType,
        startDate: startDate?.toISOString(),
        endDate: endDate?.toISOString(),
        search: searchQuery
      });

      const bookings = data.data;
      const userCodeFromAPI = data.queryByUserCode;

      setRows(bookings);
      setQueryByUserCode(userCodeFromAPI);

      // Check for in-process queries
      const hasInProcess = bookings.some(
        booking => booking.queryStatus === 'In-Process' && booking.queryByUserCode === userCodeFromAPI
      );

      setHasInProcessQuery(hasInProcess);
    } catch (error) {
      console.error('Error fetching bookings:', error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchBookingsData();
  }, [bookingType, activeTab]); // Added activeTab as dependency

  const handleSearch = () => {
    fetchBookingsData();
  };

  const handleClear = () => {
    setBookingType('all');
    setStartDate(null);
    setEndDate(null);
    setSearchQuery('');
    fetchBookingsData();
  };
  
  const handleTabChange = (event, newValue) => {
    setActiveTab(newValue);
  };
  
  return (
    <Box sx={{ width: '100%', p: 2 }}>
     
      
      {/* Add Tabs */}
      <Box sx={{ borderBottom: 1, borderColor: 'divider', mb: 2 }}>
        <Tabs value={activeTab} onChange={handleTabChange}>
          <Tab label="All Bookings" />
          <Tab label="My Bookings" />
        </Tabs>
      </Box>
      
      <Stack spacing={2}>
        <FilterControls
          bookingType={bookingType}
          setBookingType={setBookingType}
          startDate={startDate}
          setStartDate={setStartDate}
          endDate={endDate}
          setEndDate={setEndDate}
          searchQuery={searchQuery}
          setSearchQuery={setSearchQuery}
          handleSearch={handleSearch}
          handleClear={handleClear}
        />

        <DataGrid
          rows={rows}
          columns={getColumnsForSourceType(bookingType, rows, handleAddToQuery,handleOpenDialogBox, hasInProcessQuery)}
          pageSize={10}
          rowsPerPageOptions={[10, 25, 50]}
          autoHeight
          loading={loading}
          getRowId={(row) => row.UniqueId}
          sx={{
            '& .MuiDataGrid-cell': {
              borderRight: '1px solid #e0e0e0',
              borderBottom: '1px solid #e0e0e0'
            },
            '& .MuiDataGrid-columnHeader': {
              borderRight: '1px solid #e0e0e0',
              borderBottom: '2px solid #e0e0e0',
              backgroundColor: '#1976d2',
              color: 'white'
            },
            '& .MuiDataGrid-columnHeaders': {
              backgroundColor: '#1976d2',
              color: 'white'
            }
          }}
        />
      </Stack>
      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
  <DialogTitle>
    {dialogType === 'Flight' && `Flight Cities - Booking #${selectedBookingId}`}
    {dialogType === 'Hotel' && `Hotel Rooms - Booking #${selectedBookingId}`}
  </DialogTitle>
  <DialogContent>
    {dialogType === 'Flight' && (
      <>
        {flightCities.length > 0 ? (
          <ul>
            {flightCities.map((city, index) => (
              <li key={city.CityId || index}>
                {city.CityOrder}. {city.FromCity} → {city.ToCity}
              </li>
            ))}
          </ul>
        ) : (
          <p>No Flight Cities Found</p>
        )}
      </>
    )}

    {dialogType === 'Hotel' && (
      <>
        {hotelRooms.length > 0 ? (
          <ul>
            {hotelRooms.map((room, index) => (
              <li key={room.RoomId || index}>
                Room {room.RoomNumber}: {room.Adults} Adults, {room.CWB} CWB, {room.CNB} CNB, {room.Infants} Infants
              </li>
            ))}
          </ul>
        ) : (
          <p>No Hotel Rooms Found</p>
        )}
      </>
    )}
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setDialogOpen(false)} color="primary" variant="contained">
      Close
    </Button>
  </DialogActions>
</Dialog>



    </Box>
  );
};

export default FormTable;