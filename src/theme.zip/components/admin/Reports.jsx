
import React, { useEffect, useState } from 'react';
import {
  Box,
  Typography,
  Grid,
  Card,
  CardContent,
  MenuItem,
  Select,
  FormControl,
  InputLabel,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
} from '@mui/material';
import axios from 'axios';
const apiUrl = import.meta.env.VITE_API_URL;
const AdminDashboard = () => {
  const [adminList, setAdminList] = useState([]);
  const [selectedAdmin, setSelectedAdmin] = useState('all');
  const [selectedType, setSelectedType] = useState('all');
  const [bookingStats, setBookingStats] = useState({ completed: 0, pending: 0,inProgress:0,onHold:0,Cancelled:0 });
  const [bookings, setBookings] = useState([]);

  useEffect(() => {
    fetchAdmins();
    fetchBookings();
  }, [selectedAdmin, selectedType]);

  const fetchAdmins = async () => {
    const response = await axios.get(`${apiUrl}/auth/anchors`,{
      withCredentials: true,
    });
    setAdminList(response.data.data);
  };

  const fetchBookings = async () => {
    const response = await axios.get(`${apiUrl}/bookings/admin?admin=${selectedAdmin}&type=${selectedType}`,{
      withCredentials: true,
    });
    const data = response.data;
    setBookings(data);
    
    const completed = data.filter(b => b.bookingStatus === 'Completed' || b.bookingStatus === 'COMPLETED' || b.bookingStatus==="Confirmed" || b.Status==="COMPLETED" || b.visa_status==="Approved").length;
    const pending = data.filter(b => b.bookingStatus === 'Pending' || b.visa_status==="Pending"||b.Status==='Pending').length;
    const inProgress = data.filter(b => b.bookingStatus === 'IN PROGRESS' || b.visa_status==="In Process"||b.Status==='IN PROGRESS').length;
    const onHold = data.filter(b => b.bookingStatus === 'ON HOLD' || b.visa_status==="ON HOLD"||b.Status==='ON HOLD').length;
    const Cancelled = data.filter(b => b.bookingStatus === 'CANCELLED' ||b.Status==='CANCELLED'|| b.visa_status==="Rejected").length;
    setBookingStats({ completed, pending,inProgress,onHold,Cancelled  });
  };
  console.log("bookings",bookings);
  
  return (
    <Box p={3}>
      <Typography variant="h4" gutterBottom>
        Admin Dashboard
      </Typography>

      <Box display="flex" gap={2} mb={2}>
        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Admin</InputLabel>
          <Select
            value={selectedAdmin}
            label="Filter by Admin"
            onChange={(e) => setSelectedAdmin(e.target.value)}
          >
            <MenuItem value="all">All Admins</MenuItem>
            {adminList.map(admin => (
              <MenuItem key={admin.User_Id} value={admin.user_Code}>{admin.user_Name}</MenuItem>
            ))}
          </Select>
        </FormControl>

        <FormControl sx={{ minWidth: 200 }}>
          <InputLabel>Filter by Booking Type</InputLabel>
          <Select
            value={selectedType}
            label="Filter by Booking Type"
            onChange={(e) => setSelectedType(e.target.value)}
          >
            <MenuItem value="all">All Types</MenuItem>
            <MenuItem value="Flight">Flight</MenuItem>
            <MenuItem value="Hotel">Hotel</MenuItem>
            <MenuItem value="Visa">Visa</MenuItem>
            <MenuItem value="TravelPackage">Travel Package</MenuItem>
          </Select>
        </FormControl>
      </Box>
      <Typography variant="h6" gutterBottom>Total Bookings ( {bookingStats.pending+bookingStats.inProgress+bookingStats.onHold+bookingStats.completed+bookingStats.Cancelled})</Typography>
      <Grid container spacing={2}>
      
      <Grid item xs={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Pending Bookings</Typography>
              <Typography variant="h5" color="orange">{bookingStats.pending}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography variant="h6">In-Progress Bookings</Typography>
              <Typography variant="h5" color="green">{bookingStats.inProgress}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography variant="h6">On-Hold Bookings</Typography>
              <Typography variant="h5" color="green">{bookingStats.onHold}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Completed Bookings</Typography>
              <Typography variant="h5" color="green">{bookingStats.completed}</Typography>
            </CardContent>
          </Card>
        </Grid>
        <Grid item xs={6} md={2.4}>
          <Card>
            <CardContent>
              <Typography variant="h6">Cancelled  Bookings</Typography>
              <Typography variant="h5" color="green">{bookingStats.Cancelled}</Typography>
            </CardContent>
          </Card>
        </Grid>
        
      </Grid>

      <Box mt={4}>
        <Typography variant="h6" gutterBottom>
          Bookings Overview
        </Typography>
        <TableContainer component={Paper}>
          <Table>
            <TableHead>
              <TableRow>
                <TableCell>Booking ID</TableCell>
                <TableCell>Customer</TableCell>
                <TableCell>Mobile Number</TableCell>
                <TableCell>Type</TableCell>
                <TableCell>Status</TableCell>
                <TableCell>Admin</TableCell>
                <TableCell>Date</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {bookings.map((booking,index) => (
                <TableRow key={index}>
                  <TableCell>{index+1}</TableCell>
                  <TableCell>{booking.customername || booking.CustomerName || "null"}</TableCell>
                  <TableCell>{booking.mobilenumber || booking.mobile_number || booking.mobileNumber}</TableCell>
                  <TableCell>{booking.type}</TableCell>
                  <TableCell>{booking.status}</TableCell>
                  <TableCell>{booking.adminName}</TableCell>
                  <TableCell>{new Date(booking.date).toLocaleDateString()}</TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </TableContainer>
      </Box>
    </Box>
  );
};

export default AdminDashboard;
