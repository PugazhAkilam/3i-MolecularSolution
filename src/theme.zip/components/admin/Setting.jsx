import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Divider,
  Grid,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import {getStatusesByBookingType} from '../../service/status';
import axios from "axios";
import { getLocationsByBookingType } from '../../service/status';
import AddRegionForm from "./FlightRegionsList";

const apiUrl = import.meta.env.VITE_API_URL;
const AddStatusForm = () => {
  const initialData = {
    Flight: [],
    Hotel: [],
    Visa: [],
    Travel: [],
  };
  const typeId = {
    Flight: "2",
    Hotel: "3",
    Travel: "4",
    Visa: "5",
  };

  const initialPlaces = {
    Hotel: {
      Domestic: {
        Cities: [],
      },
      International: {
        Countries: {
         
        },
      },
    },
    Visa: {
      Countries: [],
    },
    Travel: {
      Domestic: {
        Cities: [],
      },
      International: {
        Countries: [],
      },
    },
  };
  //status
  const [loading,setLoading] = useState(false);
  const [type, setType] = useState("Flight"); // Default selected type
  const [status, setStatus] = useState("");
  const [statusData, setStatusData] = useState(initialData);
  const [editIndex, setEditIndex] = useState(null); // Track editing index
  //location
  const [editLocationIndex, setEditLocationIndex] = useState(null); // Track editing index for locations
  const [category, setCategory] = useState("Hotel");
  const [tripType, setTripType] = useState("Domestic");
  const [data, setData] = useState(initialPlaces);
  const [city, setCity] = useState("");
  const [country, setCountry] = useState("");
  

  const fetchStatuses = async () => {
    setLoading(true);

    try {
      const response = await getStatusesByBookingType(typeId[type]);
      if (response.success && response.data) {
        const statusDescriptions = response.data.map(
          (item) => ({id:item.Id,statusDesc:item.Stat_Desc || item.Stat_SDesc || item}
        ));
        setStatusData((prevData) => ({
          ...prevData,
          [type]: statusDescriptions,
        }));
      }
    } catch (error) {
      console.error("Error fetching statuses:", error);
    } finally {
      setLoading(false);
    }
  };
  const fetchLocations= async ()=>{
    setLoading(true);
    
    try{
      const locationData={
        category:category,
        tripType:tripType
      }
      const response = await getLocationsByBookingType(locationData);
      if(response.success && response.data){
        if (category === "Visa") {
          
          setData((prevData) => ({
            ...prevData,
            Visa: {
              ...prevData.Visa,
              Countries:response.data.map(item=>({id:item.Id,country:item.country})),
            },
          }));
          
        } else if (tripType === "Domestic") {
          
          setData((prevData) => ({
            ...prevData,
            [category]: {
              ...prevData[category],
              Domestic: {
                Cities:response.data.map(item=>({id:item.Id,city:item.city})),
              },
            },
          }));
          
        } else if (category === "Travel" && tripType === "International") {
          
          setData((prevData) => ({
            ...prevData,
            Travel: {
              ...prevData.Travel,
              International: {
                Countries: response.data.map(item=>({id:item.Id,country:item.country})),
              },
            },
          })); 
        }
        else if (category === "Hotel" && tripType === "International") {
          
          setData((prevData) => {
            
            const updatedCities = {};
            response.data.forEach((item)=>{
              if(updatedCities[item.country])
              {
                updatedCities[item.country].push({id:item.Id,city:item.city});
              }else{
                updatedCities[item.country]=[{id:item.Id,city:item.city}];
              }
            })
    
            return {
              ...prevData,
              [category]: {
                ...prevData[category],
                International: {
                  Countries: updatedCities
                },
              },
            };
          });
         
        }
      }
    }catch(error){
      console.error(`Error fetching locations`,error);
    }finally{
      setLoading(false);
    }
  }
  useEffect(() => {
    if(typeId[type]) {
     fetchStatuses();
    }
    
    if(category || tripType){
      fetchLocations();
    }
  }, [type,category,tripType]);
  

  const handleSubmit = async(e) => {
    e.preventDefault();

    if (!status.trim()) return; // Prevent empty

    if (editIndex !== null) {
      try{
        let response;
        console.log("statusData", status);
        const id = editIndex;
        
        response = await axios.put(
          `${apiUrl}/status/statuses/${id}`,
          { statusName: status },
          { withCredentials: true }
        );
        console.log("response", response.data.data);
        if (response.data.data) {
          console.log("Status updated successfully:", response.data.data);
          await fetchStatuses();
        } else {
          console.error("Failed to update status:", response.data);
        }
      }catch(error){
        console.error("Error updating status:", error);
      }
      // Clear edit state
      setEditIndex(null);
    } else {
      // Add new status
        try{
          const statusData = {
            statusName: status,
            bookingTypeId: typeId[type],
          };
          let response;
          console.log("statusData", status, typeId[type]);
          response = await axios.post(`${apiUrl}/status/statuses`, statusData, {
            withCredentials: true,
          });
          console.log("response", response.data.data);
          
          if (response.data.data) {
            console.log("Status updated successfully:", response.data.data);
            await fetchStatuses();
            
          }
          else{
            console.error("Failed to update status:", response.data);
          }
        }catch(error){
          console.error("Error updating status:", error);
        }
    }
    // Clear text field
    setStatus("");
  };
  const handleEditClick = (id) => {
    setEditIndex(id);
    const oldStatus= statusData[type].find(item=>item.id===id)
    setStatus(oldStatus.statusDesc);
  };

  const handleDeleteClick = async(id) => {
    try{
      await axios.delete(`${apiUrl}/status/statuses/${id}`, {
        withCredentials: true,
      });
     
      console.log("Status deleted successfully:");
      await fetchStatuses();
    }catch(error){
      console.error("Error deleting status:", error);
    }
    // If deleting the item you're editing → reset
    if (editIndex === index) {
      setEditIndex(null);
      setStatus("");
    }
  };

  const handleLocationChange = async (e) => {
    e.preventDefault();
  
    if (editLocationIndex !== null) {
      //edit existing location
      try {
        let response;
        const { editType, id, city: oldCity, country: oldCountry } = editLocationIndex;
  
        // Special case: Updating Hotel International Country for all cities
        if (category === "Hotel" && tripType === "International" && editType === "country" && id === null ) {
          const citiesToUpdate = data?.Hotel?.International?.Countries?.[oldCountry] || [];
  
          // Update each city in that country
          const updatePromises = citiesToUpdate.map((item) => {
            const locationId = item.id;
            const locationData = {
              category,
              tripType,
              country,        
              city: item.city 
            };
            console.log(locationData);
            return axios.put(`${apiUrl}/status/locations/${locationId}`, locationData, {
              withCredentials: true,
            });
          });
  
          await Promise.all(updatePromises);
          console.log("All cities updated with new country name");
          await fetchLocations();
  
        } else {
          // Normal update (single city or country)
          const locationId = id;
          const locationData = {
            category,
            tripType: tripType || null,
            country: editType === "country" ? country : oldCountry,
            city: editType === "city" ? city : oldCity,
          };
  
          console.log("Updating location:", locationData);
  
          response = await axios.put(`${apiUrl}/status/locations/${locationId}`, locationData, {
            withCredentials: true,
          });
  
          if (response.data) {
            console.log("Location updated successfully:", response.data);
            await fetchLocations();
          } else {
            console.error("Error updating location:", response);
          }
        }
  
      } catch (error) {
        console.error("Error during update:", error);
        return;
      }
  
      setCountry("");
      setCity("");
      setEditLocationIndex(null);
  
    } else {
      // INSERT NEW LOCATION
      try {
        const locationData = {
          category,
          tripType: tripType || null,
          country: country || null,
          city: city || null,
        };
  
        const response = await axios.post(`${apiUrl}/status/locations`, locationData, {
          withCredentials: true,
        });
  
        console.log("Inserted new location:", response.data);
        await fetchLocations();
  
      } catch (error) {
        console.error("Error inserting location:", error);
        return;
      }
  
      setCountry("");
      setCity("");
    }
  };
  
  const handleEditLocation = (editType = null, id, city = "", country = "") => {
    
    setEditLocationIndex({ editType, id, city, country });
  
    if (editType === "country") {
      setCountry(country); 
      setCity("");         
    } else if (editType === "city") {
      setCountry(country); 
      setCity(city);        
    }
  };

  const handleDeleteLocation= async(id,cities=null) =>{
    try{
      let response;
      if(id===null && cities){
        const deletePromises = cities.map((item) => {
          const locationId = item.id;
          console.log(item.id);
          return axios.delete(`${apiUrl}/status/locations/${locationId}`, {
            withCredentials: true,
          });
        });

        await Promise.all(deletePromises);
        console.log("All cities deleted with new country name");
        await fetchLocations();
      }else{
        response= await axios.delete(`${apiUrl}/status/locations/${id}`,{withCredentials:true})
        console.log('Deleted Location:',response.data);
        if(response.data){
          console.log('Location deleted successfully',response.data)
          await fetchLocations();
        }else{
          console.error('Error deleting location',response)
        }
      }
    }catch(error){
      console.error('Error during deletion:',error);
      return;
    }
  }

  return (
    <>
    <Grid container>
      <Grid item xs={6} sx={{ p: 2 }}>
        <Box
          sx={{
            width: 500,
            p: 3,
            border: "1px solid #ccc",
            borderRadius: "8px",
            mx: "auto",
            mt: 4,
          }}
        >
          <Typography variant="h5" sx={{ mb: 2, textAlign: "center" }}>
            Booking Status Management
          </Typography>
          <form onSubmit={handleSubmit}>
            {/* Dropdown */}
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel id="type-label">Type</InputLabel>
              <Select
                labelId="type-label"
                value={type}
                label="Type"
                onChange={(e) => {
                  setType(e.target.value);
                  setEditIndex(null); // Reset edit on type change
                  setStatus(""); // Clear text field
                }}
              >
                <MenuItem value="Flight">Flight</MenuItem>
                <MenuItem value="Hotel">Hotel</MenuItem>
                <MenuItem value="Visa">Visa</MenuItem>
                <MenuItem value="Travel">Travel</MenuItem>
              </Select>
            </FormControl>

            {/* Status Text */}
            <TextField
              fullWidth
              label={editIndex !== null ? "Edit Status" : "New Status"}
              value={status}
              onChange={(e) => setStatus(e.target.value)}
              sx={{ mb: 2 }}
            />

            {/* Submit Button */}
            <Button variant="contained" color="primary" sx={{width: editIndex===null?"100%":"49%"}} type="submit">
              {editIndex !== null ? "Update Status" : "Add Status"}
            </Button>
            {editIndex !== null && (
              <Button variant="contained" color="error" onClick={() => {setEditIndex(null)
              setStatus("")}} sx={{ width:"49%",ml:"2%" }}>
                Cancel Edit
              </Button>)}
          </form>

          <Divider sx={{ my: 3 }} />

          {/* Show Status List for selected Type */}
          <Typography variant="h6" sx={{ mb: 1 }}>
            Status List for {type}:
          </Typography>

          <List>
            {statusData[type].map((item) => (
              <ListItem
                key={item.id}
                secondaryAction={
                  <>
                    <IconButton
                      edge="end"
                      onClick={() => handleEditClick(item.id)}
                    >
                      <EditIcon />
                    </IconButton>
                    <IconButton
                      edge="end"
                      onClick={() => handleDeleteClick(item.id)}
                    >
                      <DeleteIcon />
                    </IconButton>
                  </>
                }
              >
                <ListItemText primary={item.statusDesc} />
              </ListItem>
            ))}
          </List>
        </Box>
      </Grid>
      <Grid item xs={6} sx={{ p: 2 }}>
        <Box
          sx={{
            width: 500,
            p: 3,
            border: "1px solid #ccc",
            borderRadius: "8px",
            mx: "auto",
            mt: 4,
          }}
        >
          <Typography variant="h5" sx={{ mb: 2, textAlign: "center" }}>
            Location Management
          </Typography>
          <form onSubmit={handleLocationChange}>
            {/* Dropdown */}
            <FormControl fullWidth sx={{ mb: 2 }}>
              <InputLabel id="category-label">Type</InputLabel>
              <Select
                labelId="category-label"
                value={category}
                label="Type"
                onChange={(e) => {
                  setCategory(e.target.value);
                  setTripType("");
                  
                }}
              >
                <MenuItem value="Hotel">Hotel</MenuItem>
                <MenuItem value="Visa">Visa</MenuItem>
                <MenuItem value="Travel">Travel</MenuItem>
              </Select>
            </FormControl>
            {category !== "Visa" && (
              <FormControl fullWidth sx={{ mb: 2 }}>
                <InputLabel id="tripType-label">Trip Type</InputLabel>
                <Select
                  labelId="tripType-label"
                  value={tripType}
                  label="Trip Type"
                  onChange={(e) => {
                    setTripType(e.target.value);
                    
                  }}
                >
                  <MenuItem value="Domestic">Domestic</MenuItem>
                  <MenuItem value="International">International</MenuItem>
                </Select>
              </FormControl>
            )}

            {tripType !== "Domestic" && (
              <TextField
                fullWidth
                label={editLocationIndex !== null ? "Edit Country" : "New Country"}
                value={country}
                onChange={(e) => {setCountry(e.target.value)
                 
                }}
                sx={{ mb: 2 }}
              />
            )}
            {!(
              category === "Visa" ||
              (category === "Travel" && tripType === "International")
            ) ? (
              <TextField
                fullWidth
                label={editLocationIndex !== null ? "Edit City" : "New City"}
                value={city}
                onChange={(e) => {setCity(e.target.value)
                 
                }}
                sx={{ mb: 2 }}
              />
            ) : null}
            <Button variant="contained" color="primary" sx={{width: editLocationIndex===null?"100%":"49%"}} type="submit">
              {editLocationIndex !== null ? "Update Location" : "Add Location"}
            </Button>
            {editLocationIndex !== null && (
              <Button variant="contained" color="error" onClick={() => {
                setEditLocationIndex(null)
                setCountry("")
                setCity("")
              }} sx={{ width:"49%",ml:"2%" }}>
                Cancel Edit
              </Button>)}
          </form>

          <Divider sx={{ my: 3 }} />

          <Typography variant="h6" sx={{ mb: 1 }}>
            Location List for {category}:
          </Typography>

          {category === "Visa" && (
            <List>
              {data?.Visa?.Countries.map((item) => (
                <ListItem
                  key={item.id}
                  secondaryAction={
                    <>
                      <IconButton
                        edge="end"
                        onClick={() => handleEditLocation("country",item.id,"",item.country)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        edge="end"
                        onClick={() => handleDeleteLocation(item.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </>
                  }
                >
                  <ListItemText primary={item.country} />
                </ListItem>
              ))}
            </List>
          )}
          {category === "Travel" && tripType === "International" ? (
            <List>
              {data?.Travel?.International?.Countries.map((item) => (
                <ListItem
                  key={item.id}
                  secondaryAction={
                    <>
                      <IconButton
                        edge="end"
                        onClick={() => handleEditLocation("country",item.id,"",item.country)}
                      >
                        <EditIcon />
                      </IconButton>
                      <IconButton
                        edge="end"
                        onClick={() => handleDeleteLocation(item.id)}
                      >
                        <DeleteIcon />
                      </IconButton>
                    </>
                  }
                >
                  <ListItemText primary={item.country} />
                </ListItem>
              ))}
            </List>
          ) : (
            <List>
              <>
                {tripType === "Domestic" &&
                  data[category]?.Domestic?.Cities?.map((item) => (
                    <ListItem
                      key={item.id}
                      secondaryAction={
                        <>
                          <IconButton
                            edge="end"
                            onClick={() => handleEditLocation("city",item.id,item.city,"")}
                          >
                            <EditIcon />
                          </IconButton>
                          <IconButton
                            edge="end"
                            onClick={() => handleDeleteLocation(item.id)}
                          >
                            <DeleteIcon />
                          </IconButton>
                        </>
                      }
                    >
                      <ListItemText primary={item.city} />
                    </ListItem>
                  ))}
                {tripType === "International" &&
                  Object.entries(
                    data[category]?.International?.Countries || {}
                  ).map(([country, cities]) => (
                    <Box
                      key={country}
                      sx={{ mb: 2, border: "1px solid #ccc", borderRadius: 2 }}
                    >
                      
                      {/* Country List Item */}
                      <ListItem
                        sx={{ bgcolor: "#f5f5f5" }}
                        secondaryAction={
                          <>
                            <IconButton
                              edge="end"
                              onClick={() => handleEditLocation("country",null,"",country)}
                            >
                              <EditIcon />
                            </IconButton>
                            <IconButton
                              edge="end"
                                onClick={() =>handleDeleteLocation(null,cities)}
                            >
                              <DeleteIcon />
                            </IconButton>
                          </>
                        }
                      >
                        <ListItemText primary={country} />
                      </ListItem>

                      {/* Cities Nested List */}
                      <List dense sx={{ pl: 4 }}>
                        {cities.map((cityObj) => (
                          <ListItem
                            key={cityObj.id}
                            secondaryAction={
                              <>
                                <IconButton
                                  edge="end"
                                  onClick={() => handleEditLocation("city",cityObj.id,cityObj.city,country)}
                                >
                                  <EditIcon fontSize="small" />
                                </IconButton>
                                <IconButton
                                  edge="end"
                                  onClick={() =>handleDeleteLocation(cityObj.id)}
                                >
                                  <DeleteIcon fontSize="small" />
                                </IconButton>
                              </>
                            }
                          >
                            <ListItemText primary={cityObj.city} />
                          </ListItem>
                        ))}
                      </List>
                    </Box>
                  ))}
              </>
            </List>
          )}
        </Box>
      </Grid>
      
    </Grid>
    <AddRegionForm/>
    </>
  );
};

export default AddStatusForm;