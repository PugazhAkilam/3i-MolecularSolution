import React, { useEffect, useState } from "react";
import {
  Box,
  Button,
  TextField,
  Select,
  MenuItem,
  InputLabel,
  FormControl,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Divider,
  Grid,
} from "@mui/material";
import EditIcon from "@mui/icons-material/Edit";
import DeleteIcon from "@mui/icons-material/Delete";
import axios from "axios";
import { getAllRegions } from '../../service/status'
const apiUrl = import.meta.env.VITE_API_URL;
const AddRegionForm=()=>{
    //flight regions
      
      const [region,setRegion] = useState("");
      const [editRegionId,setEditRegionId]= useState(null);
      const [allRegions,setAllRegions] = useState([]);
      const [loading,setLoading] = useState(false);

      const fetchRegions=async()=>{
        setLoading(true);
        try{
            const response =  await getAllRegions();
            if(response.success && response.data){
               setAllRegions(
                response.data.map((item)=>({id:item.Id,region:item.Region_Name}))
               )
            }
        }catch(error){
            console.error('Error fetching regions:',error);
        }finally{
            setLoading(false);
        }
      }
      useEffect(()=>{
        fetchRegions();
      },[]);

      const handleRegionChange=async(e)=>{
        e.preventDefault();
        if(editRegionId!==null){
            try{
                let response;
                console.log(region);
                response= await axios.put(`${apiUrl}/status/regions/${editRegionId}`,{region:region},{withCredentials:true})
                if(response.data){
                    console.log('Region updated successfully',response.data)
                    await fetchRegions();
                }else{
                    console.error('Failed to update region',response)
                }
            }catch(error){
                console.error('Error updating region:',error);
            }
            setEditRegionId(null);
        }else{
            try{
                let response;
                console.log(region)
                response = await axios.post(`${apiUrl}/status/regions`,{region:region},{withCredentials:true})
                if(response.data){
                    console.log('Region inserted successfully',response.data);
                    await fetchRegions();
                }else{
                    console.error('Failed to insert region:',response);
                }
            }catch(error){
                console.error('Error inserting region:',error)
            }
        }
        setRegion("");
      }
      const handleEditRegion=async(id,RegionToEdit)=>{
        setEditRegionId(id);
        setRegion(RegionToEdit);
      }
      const handleDeleteRegion=async(id)=>{
        try{
            let response;
            response= await axios.delete(`${apiUrl}/status/regions/${id}`,{withCredentials:true})
            if(response.data)
            {
                console.log('Region deleted successfully:',response.data)
                await fetchRegions();
            }else{
                console.error('Error deleting region:',response)
            }
        }catch(error){
            console.error('Error deleting region:',error);
        }
      }


      return(
        <>
        <Box
              sx={{
                width: 500,
                p: 3,
                border: "1px solid #ccc",
                borderRadius: "8px",
                mx: "auto",
                mt: 4,
              }}
            >
              <Typography variant="h5" sx={{ mb: 2, textAlign: "center" }}>
                Flight Management
              </Typography>
              <form onSubmit={handleRegionChange}>
                {/* Regions Text */}
                <TextField
                  fullWidth
                  label={editRegionId !== null ? "Edit Region" : "New Region"}
                  value={region}
                  onChange={(e) => setRegion(e.target.value)}
                  sx={{ mb: 2 }}
                />
        
                {/* Submit Button */}
                <Button variant="contained" color="primary" sx={{width: editRegionId===null?"100%":"49%"}} type="submit">
                  {editRegionId !== null ? "Update Region" : "Add Region"}
                </Button>
                {editRegionId !== null && (
                  <Button variant="contained" color="error" onClick={() => {setEditRegionId(null)
                  setRegion("")}} sx={{ width:"49%",ml:"2%" }}>
                    Cancel Edit
                  </Button>)}
              </form>
        
              <Divider sx={{ my: 3 }} />
        
              {/* Show Region List for flight */}
              <Typography variant="h6" sx={{ mb: 1 }}>
                Region List:
              </Typography>
        
              <List>
                {allRegions.map((item) => (
                  <ListItem
                    key={item.id}
                    secondaryAction={
                      <>
                        <IconButton
                          edge="end"
                          onClick={() => handleEditRegion(item.id,item.region)}
                        >
                          <EditIcon />
                        </IconButton>
                        <IconButton
                          edge="end"
                          onClick={() => handleDeleteRegion(item.id)}
                        >
                          <DeleteIcon />
                        </IconButton>
                      </>
                    }
                  >
                    <ListItemText primary={item.region} />
                  </ListItem>
                ))}
              </List>
            </Box>
        </>
      )
}
export default AddRegionForm;