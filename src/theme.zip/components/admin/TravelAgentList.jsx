import React, { useState } from 'react';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Button,
  Chip
} from '@mui/material';

const TravelAgentList = () => {
  const [agents, setAgents] = useState([]);

  const handleApproval = async (agentId, status) => {
    try {
      const response = await axios.patch(`${apiUrl}/agents/${agentId}/status`, {
        status
      }, {
        withCredentials: true
      });
      if (response.data.success) {
        setAgents(prev => prev.map(agent => 
          agent.id === agentId 
            ? { ...agent, status }
            : agent
        ));
        toast.success('Agent status updated successfully');
      }
    } catch (error) {
      toast.error('Failed to update agent status');
    }
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Company</TableCell>
            <TableCell>Contact</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {agents.map((agent) => (
            <TableRow key={agent.id}>
              <TableCell>{agent.name}</TableCell>
              <TableCell>{agent.company}</TableCell>
              <TableCell>{agent.contact}</TableCell>
              <TableCell>
                <Chip
                  label={agent.status}
                  color={agent.status === 'approved' ? 'success' : 'warning'}
                />
              </TableCell>
              <TableCell>
                {agent.status === 'pending' && (
                  <>
                    <Button
                      size="small"
                      color="success"
                      onClick={() => handleApproval(agent.id, 'approved')}
                    >
                      Approve
                    </Button>
                    <Button
                      size="small"
                      color="error"
                      onClick={() => handleApproval(agent.id, 'rejected')}
                    >
                      Reject
                    </Button>
                  </>
                )}
                <Button
                  size="small"
                  onClick={() => handleEdit(agent)}
                >
                  Edit
                </Button>
                <Button
                  size="small"
                  color="error"
                  onClick={() => handleRemove(agent.id)}
                >
                  Remove
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default TravelAgentList;