import React, { useEffect, useState } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import 'primereact/resources/themes/lara-light-blue/theme.css';
import 'primereact/resources/primereact.min.css';
import 'primeicons/primeicons.css';
import Box from '@mui/material/Box';
import Typography from '@mui/material/Typography';
import Stack from '@mui/material/Stack';
import axios from 'axios';
const apiurl=import.meta.env.VITE_API_URL;
// const customers = [
//   {
//     id: 'CUST001',
//     name: 'Sophia Clark',
//    Bookings:"10",
//     phone: '+1-555-123-4567',
//     bookings: [
//       { id: 'B001', date: '2024-06-01', type: 'Flight', amount: 5000, status: 'Confirmed' },
//       { id: 'B002', date: '2024-06-03', type: 'Hotel', amount: 3000, status: 'Pending' }
//     ],
//     status: 'Active'
//   },
//   {
//     id: 'CUST002',
//     name: 'Ethan Bennett',
//     Bookings:"10",
//     phone: '+1-555-987-6543',
//     bookings: [],
//     status: 'Inactive'
//   }
// ];

const statusTemplate = (rowData) => {
  const severity = rowData.status === 'Active' ? 'success' : 'danger';
  return <Tag value={rowData.status} severity={severity} style={{ margin: '4px 0' }} />;
};

const bookingStatusTemplate = (rowData) => {
  const severity = rowData.status === 'Confirmed' ? 'success' : 'warning';
  return <Tag value={rowData.status} severity={severity} style={{ margin: '4px 0' }} />;
};

const rowExpansionTemplate = (data) => {
  if (!data.bookings.length) return <Typography sx={{ m: 2, color: 'text.secondary' }}>No bookings available.</Typography>;

  return (
    <Box sx={{ p: 2, borderTop: '1px solid #ddd', backgroundColor: '#fafafa', borderRadius: 1 }}>
      <Typography variant="h6" sx={{ mb: 2, color: 'primary.main' }}>
        Bookings for {data.name}
      </Typography>
      <DataTable value={data.bookings} responsiveLayout="scroll">
        <Column field="id" header="Booking ID" />
        <Column field="date" header="Date" />
        <Column field="type" header="Type" />
        <Column field="amount" header="Amount" />
        <Column field="status" header="Status" body={bookingStatusTemplate} />
      </DataTable>
    </Box>
  );
};

const CustomerTable = () => {
  const [expandedRows, setExpandedRows] = useState(null);
  const [customers, setCustomers] = useState([]);

   useEffect(() => {
      const getAllCustomers = async () => {
       // const response = await fetch('getAllCustomers = async () => {
          const response = await axios.get(`${apiurl}/auth/user-summary`);
          const data = await response.data;
          console.log("data",data);
          setCustomers(data);
   }
   getAllCustomers();
     },[])
      
  const expandAll = () => {
    let _expandedRows = {};
    customers.forEach((c) => (_expandedRows[c.id] = true));
    setExpandedRows(_expandedRows);
  };

  const collapseAll = () => {
    setExpandedRows(null);
  };

  return (
    <Box sx={{ p: 3, backgroundColor: '#fff', boxShadow: 3, borderRadius: 2 ,mt:5}}>
      <Stack direction="row" spacing={2} justifyContent="flex-end" sx={{ mb: 2 }}>
        <Button label="Expand All" icon="pi pi-plus" onClick={expandAll} className="p-button-text" style={{ backgroundColor: '#1976d2', color: 'white' }} />
        <Button label="Collapse All" icon="pi pi-minus" onClick={collapseAll} className="p-button-text" style={{ backgroundColor: '#9e9e9e', color: 'white' }} />
      </Stack>

      <DataTable
        value={customers}
        expandedRows={expandedRows}
        onRowToggle={(e) => setExpandedRows(e.data)}
        rowExpansionTemplate={rowExpansionTemplate}
        dataKey="id"
        responsiveLayout="scroll"
        className="p-datatable-gridlines p-datatable-sm"
      >
        <Column expander style={{ width: '3em' }} />
        <Column field="id" header="Customer ID" sortable />
        <Column field="name" header="Name" sortable />
        <Column field="Bookings" header="No.Bookings" />
        <Column field="phone" header="Phone" />
      
        <Column body={statusTemplate} header="Status" />
      </DataTable>
    </Box>
  );
};

export default CustomerTable;
