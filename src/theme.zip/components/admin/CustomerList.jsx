import React, { useState, useEffect } from 'react';
import {
  Box,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Paper,
  Switch,
  IconButton,
  Typography
} from '@mui/material';
import { VisibilityOutlined } from '@mui/icons-material';

const CustomerList = () => {
  const [customers, setCustomers] = useState([]);

  const handleBlockUser = async (userId, currentStatus) => {
    try {
      const response = await axios.patch(`${apiUrl}/users/${userId}/status`, {
        isBlocked: !currentStatus
      }, {
        withCredentials: true
      });
      if (response.data.success) {
        // Update local state
        setCustomers(prev => prev.map(customer => 
          customer.id === userId 
            ? { ...customer, isBlocked: !currentStatus }
            : customer
        ));
        toast.success(`User successfully ${currentStatus ? 'unblocked' : 'blocked'}`);
      }
    } catch (error) {
      toast.error('Failed to update user status');
    }
  };

  return (
    <TableContainer component={Paper}>
      <Table>
        <TableHead>
          <TableRow>
            <TableCell>Name</TableCell>
            <TableCell>Email</TableCell>
            <TableCell>Phone</TableCell>
            <TableCell>Status</TableCell>
            <TableCell>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {customers.map((customer) => (
            <TableRow key={customer.id}>
              <TableCell>{customer.name}</TableCell>
              <TableCell>{customer.email}</TableCell>
              <TableCell>{customer.phone}</TableCell>
              <TableCell>
                <Switch
                  checked={!customer.isBlocked}
                  onChange={() => handleBlockUser(customer.id, customer.isBlocked)}
                />
              </TableCell>
              <TableCell>
                <IconButton>
                  <VisibilityOutlined />
                </IconButton>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default CustomerList;