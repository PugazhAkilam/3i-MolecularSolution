import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Grid, TextField, Container, Paper, FormControl, InputLabel, Select, MenuItem } from '@mui/material';

import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AddIcon from '@mui/icons-material/Add';
const apiUrl=import.meta.env.VITE_API_URL;
import { getAllStatuses ,getStatusesByBookingType} from '../service/status';
// Add this import at the top
import dayjs from 'dayjs';

// Add these imports at the top
import { useLocation, useNavigate } from 'react-router-dom';

const FlightBookingForm = () => {
  // Add these at the top of the component
  const location = useLocation();
  const navigate = useNavigate();
  const { bookingData, isEditing } = location.state || { bookingData: null, isEditing: false };
    
     console.log("bookingData",bookingData);
     
  // Convert string dates to dayjs objects
  const convertToDate = (dateString) => {
    if (!dateString) return null;
    return dayjs(dateString);
  };
  
  // Modify your state initializations to use the passed data if available
  const [tripType, setTripType] = useState(bookingData?.tripType || 'Single');
  const [fareType, setFareType] = useState(bookingData?.fareType || 'Normal');
  const [departureDate, setDepartureDate] = useState(convertToDate(bookingData?.departureDate));
  const [returnDate, setReturnDate] = useState(convertToDate(bookingData?.returnDate));
  const [segment1Date, setSegment1Date] = useState(convertToDate(bookingData?.segment1Date));
  const [segment2Date, setSegment2Date] = useState(convertToDate(bookingData?.segment2Date));
  const [segment3Date, setSegment3Date] = useState(convertToDate(bookingData?.segment3Date));
  const [adults, setAdults] = useState(bookingData?.adults || 1);
  const [children, setChildren] = useState(bookingData?.children || 0);
  const [infants, setInfants] = useState(bookingData?.infants || 0);
  const [childrenAge, setChildrenAge] = useState(bookingData?.childrenAges || '');
  const [mobileNumber, setMobileNumber] = useState(bookingData?.mobileNumber || '');
  const [customername, setCustomerName] = useState(bookingData?.customername || '');
  const [bookingStatus, setBookingStatus] = useState(bookingData?.bookingStatus || 'Pending');
    // Add this with your other useState declarations (around line 40-45)
    const [remarks, setRemarks] = useState(bookingData?.remarks || '');
  const [statusOptions, setStatusOptions] = useState([]);
  const [cityPairs, setCityPairs] = useState([{ from: '', to: '' }]);
  useEffect(() => {
    if (bookingData && bookingData.CityNames) {
      try {
        // Parse the CityNames string if it's a string
        const cityNamesData = typeof bookingData.CityNames === 'string' 
          ? JSON.parse(bookingData.CityNames) 
          : bookingData.CityNames;
          
        if (Array.isArray(cityNamesData) && cityNamesData.length > 0) {
          // Transform the data to match the cityPairs format
          const formattedCityPairs = cityNamesData.map(city => ({
            from: city.FromCity,
            to: city.ToCity
          }));
          
          setCityPairs(formattedCityPairs);
        }
      } catch (error) {
        console.error('Error parsing city pairs data:', error);
      }
    }
  }, [bookingData]);

  const addCityPair = () => {
    const lastPair = cityPairs[cityPairs.length - 1];
    setCityPairs([...cityPairs, { from: lastPair.to, to: '' }]);
  };
  console.log("render");
  
  const handleCancel = () => {
    // Check if we came from another page (like MyQuery)
    const returnPath = sessionStorage.getItem('returnToLocation');
    
    if (returnPath) {
      // If we have a return path, navigate back to it
      navigate(returnPath);
    } else {
      // Otherwise, just reset the form
      setTripType('Single');
      setFareType('Normal');
      setDepartureDate(null);
      setReturnDate(null);
      setSegment1Date(null);
      setSegment2Date(null);
      setSegment3Date(null);
      setAdults(1);
      setChildren(0);
      setInfants(0);
      setChildrenAge('');
      setMobileNumber('');
      setCustomerName('');
      setBookingStatus('Pending');
      
      // Reset remarks field
      const remarksField = document.querySelector('[name="remarks"]');
      if (remarksField) remarksField.value = '';
      
      // Optionally, you could navigate to a different page
      // navigate('/');
    }
  };
  const handleCityChange = (index, field, value) => {
    const newCityPairs = [...cityPairs];
    newCityPairs[index][field] = value;
    setCityPairs(newCityPairs);
  };
  const handleSubmit = async () => {
    try {
      const formData = {
        tripType,
        fareType,
        departureDate,
        returnDate,
        segment1Date,
        segment2Date,
        segment3Date,
        passengers: {
          adults,
          children,
          infants,
          childrenAge
        },
        mobileNumber,
        customername,
        bookingStatus,
        remarks: remarks, // Use the 
        cityPairs  
      };

      let response;
      
      if (isEditing && bookingData) {
        // Update existing booking
        response = await axios.put(`${apiUrl}/flight/bookings/${bookingData.id}`, formData, {
          withCredentials: true
        });
      } else {
        // Create new booking
        response = await axios.post(`${apiUrl}/flight/bookings`, formData, {
          withCredentials: true
        });
      }
      
      if (response.data.success) {
        // Reset form fields or handle success
        setTripType('Single');
        setFareType('Normal');
        setDepartureDate(null);
        setReturnDate(null);
        setSegment1Date(null);
        setSegment2Date(null);
        setSegment3Date(null);
        setAdults(0);
        setChildren(0);
        setInfants(0);
        setChildrenAge('');
        setMobileNumber('');
        setBookingStatus('Pending');
        // Reset remarks field
            // ... other state resets
            setRemarks(''); // Reset remarks using the state setter
            // Remove the DOM manipulation code for remarks
        
        // Show success message
        toast.success(isEditing ? 'Booking updated successfully!' : 'Booking created successfully!');
        
        // If we're editing, return to the previous page
        if (isEditing) {
          const returnPath = sessionStorage.getItem('returnToLocation') || '/my-query';
          navigate(returnPath);
        }
      }
    } catch (error) {
      console.error('Error creating booking:', error);
      // Show validation errors if any
      if (error.response?.data?.errors) {
        const errorMessages = error.response.data.errors
          .map(err => err.msg)
          .join('\n');
        alert(`Validation errors:\n${errorMessages}`);
      } else {
        alert('An error occurred while creating the booking');
      }
    }
  };

  
  // Add this state at the top with your other state variables
  const [hasLoaded, setHasLoaded] = useState(false);
  
  useEffect(() => {
    const fetchStatusOptions = async () => {
      // Skip if already loaded
      if (hasLoaded) return;
      
      try {
        const response = await getStatusesByBookingType(2);
        if (response.success && response.data) {
          setStatusOptions(response.data);
          setBookingStatus(response.data[0].Stat_Desc);
          setHasLoaded(true); // Mark as loaded
        }
      } catch (error) {
        console.error('Error fetching status options:', error);
        toast.error('Failed to load booking status options');
      }
    };
    
    fetchStatusOptions();
  }, [hasLoaded]); // Add hasLoaded to dependencies

  const datePickerProps = {
    slotProps: {
      textField: {
        fullWidth: true,
        margin: 'normal',
      },
    },
  };

  return (
    <Container sx={{ p: 3, mx: 'auto' }}>
      <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h6" gutterBottom>
          Flight Booking Form
        </Typography>
        <Grid item xs={12}>
          <TextField
            fullWidth
            label="Name"
            placeholder="Enter Customer name"
            margin="normal"
            value={customername}
            onChange={(e) => setCustomerName(e.target.value)}
          />
        </Grid>

      
     

        {/* Trip Type and Fare Type */}
        <Grid container spacing={4}>
          <Grid item xs={6} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel>Trip Type</InputLabel>
              <Select
                value={tripType}
                label="Trip Type"
                onChange={(e) => setTripType(e.target.value)}
              >
                <MenuItem value="Single">Single</MenuItem>
                <MenuItem value="Roundtrip">Roundtrip</MenuItem>
                <MenuItem value="Multicity">Multicity</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel>Fare Type</InputLabel>
              <Select 
                value={fareType}
                onChange={(e) => setFareType(e.target.value)}
                label="Fare Type"
              >
                <MenuItem value="Normal">Normal</MenuItem>
                <MenuItem value="Refundable">Refundable</MenuItem>
                <MenuItem value="Non-Refundable">Non-Refundable</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>
        
         

        {cityPairs.map((pair, index) => (
          <Grid container spacing={2} key={index} sx={{ mt: index > 0 ? 2 : 0 }}>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label={`From ${index + 1}`}
                placeholder="Enter departure city"
                margin="normal"
                value={pair.from}
                onChange={(e) => handleCityChange(index, 'from', e.target.value)}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label={`To ${index + 1}`}
                placeholder="Enter destination city"
                margin="normal"
                value={pair.to}
                onChange={(e) => handleCityChange(index, 'to', e.target.value)}
              />
            </Grid>
          </Grid>
        ))}

        {/* Add City Button for Multicity */}
        {tripType === 'Multicity' && cityPairs[cityPairs.length - 1].to && (
          <Button
            variant="outlined"
            onClick={addCityPair}
            sx={{ mt: 2 }}
            startIcon={<AddIcon />}
          >
            Add City
          </Button>
        )}

        {/* Date Pickers */}
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          {tripType === 'Single' && (
            <Grid container spacing={2}>
              <Grid item xs={12}>
                <DatePicker
                  label="Departure Date"
                  value={departureDate}
                  onChange={(newValue) => setDepartureDate(newValue)}
                  {...datePickerProps}
                />
              </Grid>
            </Grid>
          )}
          {tripType === 'Roundtrip' && (
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <DatePicker
                  label="Departure Date"
                  value={departureDate}
                  onChange={(newValue) => setDepartureDate(newValue)}
                  {...datePickerProps}
                />
              </Grid>
              <Grid item xs={6}>
                <DatePicker
                  label="Return Date"
                  value={returnDate}
                  onChange={(newValue) => setReturnDate(newValue)}
                  {...datePickerProps}
                />
              </Grid>
            </Grid>
          )}
          {tripType === 'Multicity' && (
            <Grid container spacing={2}>
              {[segment1Date, segment2Date, segment3Date].map((date, index) => (
                <Grid item xs={4} key={index}>
                  <DatePicker
                    label={`Segment ${index + 1}`}
                    value={date}
                    onChange={(newValue) => {
                      if (index === 0) setSegment1Date(newValue);
                      if (index === 1) setSegment2Date(newValue);
                      if (index === 2) setSegment3Date(newValue);
                    }}
                    {...datePickerProps}
                  />
                </Grid>
              ))}
            </Grid>
          )}
        </LocalizationProvider>

        {/* Passenger Info */}
        <Typography variant="subtitle1" sx={{ mt: 2 }}>
          Number of Passengers
        </Typography>
        <Grid container spacing={2}>
          {['Adults', 'Children', 'Infants'].map((label, index) => (
            <Grid item xs={4} key={index}>
              <TextField
                label={label}
                value={label === 'Adults' ? adults : label === 'Children' ? children : infants}
                onChange={(e) => {
                  const value = parseInt(e.target.value) || 0;
                  if (label === 'Adults') setAdults(Math.max(0, value));
                  else if (label === 'Children') setChildren(Math.max(0, value));
                  else setInfants(Math.max(0, value));
                }}
                type="text"
                fullWidth
              />
            </Grid>
          ))}
        </Grid>

        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={4}>
            <TextField
              fullWidth
              label="Age of Children"
              placeholder="e.g. 5, 7"
              margin="normal"
              value={childrenAge}
              onChange={(e) => setChildrenAge(e.target.value)}
            />
          </Grid>
          <Grid item xs={4}>
            <TextField
              fullWidth
              label="Mobile Number"
              placeholder="90000 80000"
              margin="normal"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
            />
          </Grid>
          <Grid item xs={4}>
          <FormControl fullWidth margin="normal">
      <InputLabel>Booking Status</InputLabel>
      <Select 
        value={bookingStatus}
        onChange={(e) => setBookingStatus(e.target.value)}
        label="Booking Status"
      >
        {statusOptions.length > 0 ? (
          statusOptions.map((status) => (
            <MenuItem key={status.Id} value={status.Stat_Desc}>
              {status.Stat_Desc}
            </MenuItem>
          ))
        ) : (
          // Fallback to hardcoded values if API fails
          [
            <MenuItem key="pending" value="Pending">Pending</MenuItem>,
            <MenuItem key="inprogress" value="InProgress">InProgress</MenuItem>,
            <MenuItem key="completed" value="Completed">Completed</MenuItem>
          ]
        )}
      </Select>
    </FormControl>
          </Grid>
        </Grid>

        {/* Remarks */}
        <TextField
          fullWidth
          name="remarks"
          label="Remarks"
          placeholder="Enter any additional notes or remarks here..."
          multiline
          rows={3}
          margin="normal"
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
        />
        {/* Update Buttons */}
        <Grid container spacing={2} sx={{ mt: 2, justifyContent: 'center' }}>
          <Grid item>
            <Button variant="contained" color="error" onClick={handleCancel}>
              Cancel
            </Button>
          </Grid>
          <Grid item>
            <Button variant="contained" color="success" onClick={handleSubmit}>
              {isEditing ? 'Update Booking' : 'Book Flight'}
            </Button>
          </Grid>
        </Grid>
      </Paper>
    </Container>
  );
};

export default FlightBookingForm;
