import React, { useState, useEffect } from "react";
import Box from "@mui/material/Box";
import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { DataGrid } from "@mui/x-data-grid";
import Paper from "@mui/material/Paper";
import axios from "axios";
import { useAuth } from "../context/AuthContext";
import CircularProgress from "@mui/material/CircularProgress";
import Button from "@mui/material/Button";
import Dialog from "@mui/material/Dialog";

import DialogContent from "@mui/material/DialogContent";
import DialogContentText from "@mui/material/DialogContentText";
import DialogActions from '@mui/material/DialogActions';
import DialogTitle from "@mui/material/DialogTitle";
import EditIcon from "@mui/icons-material/Edit";
import IconButton from "@mui/material/IconButton";
import TextField from "@mui/material/TextField";
import Grid from "@mui/material/Grid";
import RoomIcon from '@mui/icons-material/Room';
//import { useAuth } from "../context/AuthContext";


const apiUrl = import.meta.env.VITE_API_URL;


  // Common utility function for date formatting
const formatDate = (value) => {
  if (!value) return '';
  try {
    const date = new Date(value);
    return date.toLocaleDateString();
  } catch {
    return value;
  }
};

  // Date column creator
  export const createDateColumn = (field, headerName) => ({
    field,
    headerName,
    width: 130,
    renderCell: (params) => formatDate(params.row[field])
  });


// Import useNavigate at the top of the file
import { useNavigate } from 'react-router-dom';
import { fetchFlightBookingCities, fetchHotelBookingRooms } from "../service/bookingService";

function MyQuoteEditPage() {

  
  const [mainTab, setMainTab] = useState("FlightBookings");
  const [subTab, setSubTab] = useState("All");
  const [bookingData, setBookingData] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusOptions, setStatusOptions] = useState([]);
  const { user } = useAuth();
  const [userType, setUserType] = useState('admin');

  const handleClickAddressIcon = (row) => {
    handleOpenDialogBox(row);
  };
  
  console.log("user",user.userType);
  // Define column sets for each booking type
const columnsByType = {
  FlightBookings: [
    { field: "id", headerName: "Booking ID", width: 100 },
  { field: "tripType", headerName: "Trip Type", width: 120 },
  { field: "fareType", headerName: "Fare Type", width: 120 },

  // Correct format for date columns
  createDateColumn('departureDate', 'Departure Date'),
  createDateColumn('returnDate', 'Return Date'),
  createDateColumn('segment1Date', 'Segment 1 Date'),
  createDateColumn('segment2Date', 'Segment 2 Date'),
  createDateColumn('segment3Date', 'Segment 3 Date'),
  {
    field: 'fromToAddress',
    headerName: 'From-To Address',
    width: 150,
    sortable: false,
    filterable: false,
    renderCell: (params) => (
      <div
        style={{
          cursor: 'pointer',
          display: 'flex',
          alignItems: 'center',
          justifyContent: 'center'
        }}
        onClick={() => handleClickAddressIcon(params.row)}

      >
        <span role="img" aria-label="address" style={{ fontSize: '1.2rem' }}>📍</span>
      </div>
    )},
  { field: "adults", headerName: "Adults", width: 100 },
  { field: "children", headerName: "Children", width: 100 },
  { field: "infants", headerName: "Infants", width: 100 },
  { field: "childrenAges", headerName: "Children Ages", width: 140 },
  { field: "mobileNumber", headerName: "Mobile Number", width: 150 },
  { field: "bookingStatus", headerName: "Booking Status", width: 140 },
  { field: "remarks", headerName: "Remarks", width: 200 },
  
  createDateColumn('createdAt', 'Created At'),
 
  ],
  HotelBookings: [
    { field: "BookingId", headerName: "Booking ID", width: 100 },
    { field: "BookingType", headerName: "Booking Type", width: 150 },
    { field: "Country", headerName: "Country", width: 120 },
    { field: "City", headerName: "City", width: 120 },
    createDateColumn('CheckInDate', 'Check-In Date'),
    createDateColumn('CheckOutDate', 'Check Out Date'),
    {
      field: 'fromToAddress',
      headerName: 'From-To Address',
      width: 150,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <div
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onClick={() => handleClickAddressIcon(params.row)}

        >
         <RoomIcon style={{ fontSize: '1.2rem', color: '#1976d2' }} />
         <span style={{ fontSize: '1rem' }}>Room</span>
        </div>
      )},
    { field: "HotelName", headerName: "Hotel Name", width: 150 },
    { field: "HotelStarRating", headerName: "Hotel Star Rating", width: 150 },
    { field: "Adults", headerName: "Adults", width: 80 },
    { field: "Children", headerName: "Children", width: 80 },
    { field: "Infants", headerName: "Infants", width: 80 },
    { field: "AgeOfChildren", headerName: "Age Of Children", width: 150 },
    { field: "BudgetRange", headerName: "Budget Range", width: 130 },
    { field: "MealPlan", headerName: "Meal Plan", width: 120 },
    { field: "BookingStatus", headerName: "Booking Status", width: 130 },
    { field: "Remarks", headerName: "Remarks", width: 200 },
    
    createDateColumn('CreatedOn', 'Created On'),
 
    
  ],
  TravelPackageBookings:[
    { field: "BookingId", headerName: "Booking ID", width: 100 },
    { field: "PackageType", headerName: "Package Type", width: 120 },
    { field: "Countries", headerName: "Countries", width: 200 },
    { field: "City", headerName: "City", width: 120 },
    createDateColumn('CheckInDate', 'Check-In Date'),
    createDateColumn('CheckOutDate', 'Check Out Date'),
    { field: "HotelName", headerName: "Hotel Name", width: 150 },
    { field: "HotelRating", headerName: "Hotel Rating", width: 120 },
    { field: "Adults", headerName: "Adults", width: 100 },
    { field: "Children", headerName: "Children", width: 100 },
    { field: "Infants", headerName: "Infants", width: 100 },
    { field: "ChildrenAges", headerName: "Children Ages", width: 150 },
    { field: "Budget", headerName: "Budget", width: 120 },
    { field: "MealPlan", headerName: "Meal Plan", width: 120 },
    { field: "Status", headerName: "Status", width: 120 },
   
    { field: "Remarks", headerName: "Remarks", width: 150 },
   
    createDateColumn('CreatedOn', 'Created On'),
  
    
  ],
  VisaProcess: [
    { field: "visa_id", headerName: "Visa ID", width: 100 },
    { field: "countries", headerName: "Countries", width: 200 },
  
  
    { field: "visa_type", headerName: "Visa Type", width: 150 },
   
    createDateColumn('travel_date', 'Travel Date'),
    { field: "adults", headerName: "Adults", width: 100 },
    { field: "children", headerName: "Children", width: 100 },
    { field: "infants", headerName: "Infants", width: 100 },
    { field: "children_ages", headerName: "Children Ages", width: 150 },
    { field: "mobile_number", headerName: "Mobile Number", width: 150 },
    { field: "visa_status", headerName: "Status", width: 120 },
    { field: "remarks", headerName: "Remarks", width: 150 },
  
    createDateColumn('created_on', 'Created On'),
  ],
};
  //const { user, loading: authLoading, error: authError } = useAuth();
  // Add state for dialog
  const [openDialog, setOpenDialog] = useState(false);
  const [selectedBooking, setSelectedBooking] = useState(null);
  const navigate = useNavigate();
  const [selectedBookingId, setSelectedBookingId] = useState(null);
  const [dialogType, setDialogType] = useState(''); // "Flight" or "Hotel"
  const [flightCities, setFlightCities] = useState([]);
  const [dialogOpen, setDialogOpen] = useState(false);
  const [hotelRooms, setHotelRooms] = useState([]);
   

  console.log("selectedBookingId",selectedBookingId);
  
  const handleOpenDialogBox = async (rowData) => {
    try {
      console.log('Opening dialog box for row:', rowData);
  
      setSelectedBookingId(rowData.id);
  
      if (rowData.bookingname === 'flight') {
        setDialogType('Flight');
        const response = await fetchFlightBookingCities(rowData.id);
        if (Array.isArray(response.data)) {
          setFlightCities(response.data);
        } else {
          setFlightCities([]);
        }
      } else if (rowData.bookingname === 'hotel') {
        setDialogType('Hotel');
        const response = await fetchHotelBookingRooms(rowData.BookingId);
        if (Array.isArray(response.data)) {
          setHotelRooms(response.data);
        } else {
          setHotelRooms([]);
        }
      } else {
        setDialogType('');
        setFlightCities([]);
        setHotelRooms([]);
      }
  
      setDialogOpen(true);
    } catch (error) {
      console.error('Error fetching booking details:', error);
      setFlightCities([]);
      setHotelRooms([]);
      setDialogOpen(true); // Open anyway to show error/empty
    }
  };
  
  // Function to handle edit button click
  const handleEditClick = (params) => {
    // Store the current location to return to it later
    sessionStorage.setItem('returnToLocation', window.location.pathname);
    
    // Navigate based on booking type
    if (mainTab === "FlightBookings") {
      if(user.userType===2){
        navigate('/admin/flight', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }else if(user.userType===3){
        navigate('/anchor/flight', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }
    } else if (mainTab === "HotelBookings") {
      if(user.userType===2){
        navigate('/admin/hotel', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }else if(user.userType===3){
        navigate('/anchor/hotel', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }
    } else if (mainTab === "TravelPackageBookings") {
      if(user.userType===2){
        navigate('/admin/travel', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }else if(user.userType===3){
        navigate('/anchor/travel', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }
    } else if (mainTab === "VisaProcess") {
      if(user.userType===2){
        navigate('/admin/visa', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }else if(user.userType===3){
        navigate('/anchor/visa', { 
          state: { 
            bookingData: params.row,
            isEditing: true
          } 
        });
      }
    } else {
      // Fallback to dialog for any other booking types
      setSelectedBooking(params.row);
      setOpenDialog(true);
    }
  };

  // Function to handle dialog close
  const handleCloseDialog = () => {
    setOpenDialog(false);
    setSelectedBooking(null);
  };

  // Function to handle save changes
  const handleSaveChanges = async () => {
    try {
      // Here you would implement the API call to update the booking
      // For example:
      // await axios.put(`${apiUrl}/bookings/${selectedBooking.BookingId}`, selectedBooking, {
      //   withCredentials: true
      // });
      
      // Update local state
      const updatedData = bookingData.map(booking => 
        booking.BookingId === selectedBooking.BookingId ? selectedBooking : booking
      );
      setBookingData(updatedData);
      
      // Close dialog
      handleCloseDialog();
      
      // Optionally refresh data
      // fetchBookingData();
    } catch (err) {
      console.error("Error updating booking:", err);
      // Handle error
    }
  };

  // Function to handle input change in dialog
  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setSelectedBooking(prev => ({
      ...prev,
      [name]: value
    }));
  };

  // Add action column to each column set
  const getColumnsWithActions = (columns) => {
    return [
      {
        field: "actions",
        headerName: "Actions",
        width: 100,
        renderCell: (params) => (
          <IconButton
            color="primary"
            onClick={() => handleEditClick(params)}
            aria-label="edit"
          >
            <EditIcon />
          </IconButton>
        ),
      },
      ...columns,
      
    ];
  };

  // Use the appropriate columns based on the selected main tab with actions added
  const baseColumns = columnsByType[mainTab] || columnsByType.FlightBookings;
  const activeColumns = getColumnsWithActions(baseColumns);

  // Fetch unique booking statuses for sub-tabs
  useEffect(() => {
    fetchUniqueStatuses();
  }, []);

  // Fetch booking data when main tab or sub tab changes
  useEffect(() => {
    fetchBookingData();
  }, [mainTab, subTab]);

  // Update the useEffect to fetch statuses when main tab changes
  useEffect(() => {
    fetchUniqueStatuses();
    fetchBookingData();
  }, [mainTab]);

  // Update the useEffect for sub tab changes
  useEffect(() => {
    fetchBookingData();
  }, [subTab]);

  // Modify fetchUniqueStatuses to get statuses specific to the selected main tab
  const fetchUniqueStatuses = async () => {
    try {
      const response = await axios.get(`${apiUrl}/status/booking-statuses/unique/${mainTab}`, {
        withCredentials: true
      });
      if (response.data.success) {
        // Add 'All' option to the beginning of the array
        setStatusOptions(['All', ...response.data.data]);
      } else {
        setError("Failed to fetch status options");
      }
    } catch (err) {
      console.error("Error fetching status options:", err);
      // Fallback to default options if API fails
      setStatusOptions(['All', 'Inprocess', 'On-Hold', 'Completed', 'Rejected', 'Approved']);
    }
  };

  const fetchBookingData = async () => {
    try {
      setLoading(true);
      const response = await axios.get(`${apiUrl}/status/booking-statuses/${mainTab}`, {
        withCredentials: true
      });
      if (response.data.success) {
        setBookingData(response.data.data);
      } else {
        setError("Failed to fetch booking data");
      }
    } catch (err) {
      console.error("Error fetching booking data:", err);
      setError("An error occurred while fetching booking data");
    } finally {
      setLoading(false);
    }
  };

  const handleMainTabChange = (event, newValue) => {
    console.log("tabs",newValue);
    
    setMainTab(newValue);
    setSubTab("All"); // Reset subtab when main tab changes
  };

  const handleSubTabChange = (event, newValue) => {
    setSubTab(newValue);
  };
  const paginationModel = { page: 0, pageSize: 5 };
  // Filter data based on sub tab
  const filteredRows = subTab !== "All"
    ? bookingData.filter(row => {
        // Handle different variations of status names
        const rowStatus = (row.BookingStatus || row.bookingStatus || row.Status || row.visa_status || "").toLowerCase();
        const tabStatus = subTab.toLowerCase();
        
        return rowStatus === tabStatus ||
               (tabStatus === 'inprocess' && (rowStatus === 'in-process' || rowStatus === 'in process')) ||
               (tabStatus === 'on-hold' && rowStatus === 'on hold');
      })
    : bookingData;

  // Generate dialog fields based on the selected booking type
  const renderDialogFields = () => {
    if (!selectedBooking) return null;
    
    // Get fields based on the current main tab
    const fields = columnsByType[mainTab].map(column => ({
      field: column.field,
      headerName: column.headerName
    }));
    
    return fields.map(field => {
      // Skip certain fields that shouldn't be editable
      if (['BookingId', 'createdAt', 'CreatedOn', 'created_on'].includes(field.field)) {
        return null;
      }
      
      return (
        <Grid item xs={12} sm={6} key={field.field}>
          <TextField
            margin="dense"
            name={field.field}
            label={field.headerName}
            type="text"
            fullWidth
            variant="outlined"
            value={selectedBooking[field.field] || ''}
            onChange={handleInputChange}
          />
        </Grid>
      );
    });
  };

  return (
    <div>
      <h1>My Query</h1>
      {/* Main Tabs */}
      <Box sx={{ width: "100%", mb: 2 }}>
        <TabContext value={mainTab}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleMainTabChange} aria-label="Main Tabs">
              <Tab label="Flight" value="FlightBookings" />
              <Tab label="Hotel" value="HotelBookings" />
              <Tab label="Travel Booking" value="TravelPackageBookings" />
              <Tab label="Visa" value="VisaProcess" />
            </TabList>
          </Box>
        </TabContext>
      </Box>

      {/* Sub Tabs - Now Dynamic */}
      <Box sx={{ width: "100%" }}>
        <TabContext value={subTab}>
          <Box sx={{ borderBottom: 1, borderColor: "divider" }}>
            <TabList onChange={handleSubTabChange} aria-label="Sub Tabs">
              {statusOptions.map((label) => (
                <Tab key={label} label={label} value={label} />
              ))}
            </TabList>
          </Box>

          <TabPanel value={subTab}>
            <div style={{ height: 400, width: "100%" }}>
              <Paper elevation={3} style={{ padding: "10px" }}>
                {loading ? (
                  <Box sx={{ display: 'flex', justifyContent: 'center', p: 3 }}>
                    <CircularProgress />
                  </Box>
                ) : error ? (
                  <Box sx={{ p: 2, color: 'error.main' }}>{error}</Box>
                ) : filteredRows.length === 0 ? (
                  <Box sx={{ p: 2, textAlign: 'center' }}>No bookings found</Box>
                ) : (
                  <DataGrid
                    rows={filteredRows}
                    columns={activeColumns} 
                    initialState={{ pagination: { paginationModel } }}
                    pageSizeOptions={[5, 10]}
                    rowsPerPageOptions={[10]}
                    getRowId={(row) => row.BookingId || Math.random().toString()}
                  />
                )}
              </Paper>
            </div>
          </TabPanel>
        </TabContext>
      </Box>

      {/* Edit Dialog */}
      <Dialog open={openDialog} onClose={handleCloseDialog} maxWidth="md" fullWidth>
        <DialogTitle>Edit Booking</DialogTitle>
        <DialogContent>
          <DialogContentText>
            Update the booking information below.
          </DialogContentText>
          <Grid container spacing={2} sx={{ mt: 1 }}>
            {renderDialogFields()}
          </Grid>
        </DialogContent>
        <DialogActions>
          <Button onClick={handleCloseDialog}>Cancel</Button>
          <Button onClick={handleSaveChanges} variant="contained" color="primary">
            Save Changes
          </Button>
        </DialogActions>
      </Dialog>

      <Dialog open={dialogOpen} onClose={() => setDialogOpen(false)} maxWidth="sm" fullWidth>
  <DialogTitle>
    {dialogType === 'Flight' && `Flight Cities - Booking #${selectedBookingId}`}
    {dialogType === 'Hotel' && `Hotel Rooms - Booking #${selectedBookingId}`}
  </DialogTitle>
  <DialogContent>
    {dialogType === 'Flight' && (
      <>
        {flightCities.length > 0 ? (
          <ul>
            {flightCities.map((city, index) => (
              <li key={city.CityId || index}>
                {city.CityOrder}. {city.FromCity} → {city.ToCity}
              </li>
            ))}
          </ul>
        ) : (
          <p>No Flight Cities Found</p>
        )}
      </>
    )}

    {dialogType === 'Hotel' && (
      <>
        {hotelRooms.length > 0 ? (
          <ul>
            {hotelRooms.map((room, index) => (
              <li key={room.RoomId || index}>
                Room {room.RoomNumber}: {room.Adults} Adults, {room.CWB} CWB, {room.CNB} CNB, {room.Infants} Infants
              </li>
            ))}
          </ul>
        ) : (
          <p>No Hotel Rooms Found</p>
        )}
      </>
    )}
  </DialogContent>
  <DialogActions>
    <Button onClick={() => setDialogOpen(false)} color="primary" variant="contained">
      Close
    </Button>
  </DialogActions>
</Dialog>
    </div>
  );
}

export default MyQuoteEditPage;