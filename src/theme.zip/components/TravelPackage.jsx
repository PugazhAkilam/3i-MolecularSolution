import React, { useState, useEffect } from 'react';
import { Box, Button, Typography, Grid, TextField, FormControl, InputLabel, Select, MenuItem, Paper, Container } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { getStatusesByBookingType } from '../service/status';
const apiUrl=import.meta.env.VITE_API_URL;
// ... existing code ...
import { useLocation, useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
// ... existing code ...
const countryData = {
  USA: ['New York', 'Los Angeles', 'Chicago', 'Miami', 'Las Vegas'],
  UK: ['London', 'Manchester', 'Birmingham', 'Edinburgh', 'Glasgow'],
  // UAE: ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah'],
  // Singapore: ['Singapore City'],
  Thailand: ['Bangkok', 'Phuket', 'Pattaya', 'Chiang Mai', 'Krabi'],
  // Malaysia: ['Kuala Lumpur', 'Penang', 'Langkawi', 'Johor Bahru', 'Malacca'],
  // Indonesia: ['Bali', 'Jakarta', 'Lombok', 'Yogyakarta', 'Bandung'],
  France: ['Paris', 'Nice', 'Lyon', 'Marseille', 'Bordeaux'],
  Italy: ['Rome', 'Venice', 'Florence', 'Milan', 'Naples'],

  // Newly Added:
  Japan: ['Tokyo', 'Kyoto', 'Osaka', 'Hiroshima', 'Sapporo'],
  Australia: ['Sydney', 'Melbourne', 'Brisbane', 'Perth', 'Adelaide'],

  // Spain: ['Barcelona', 'Madrid', 'Seville', 'Valencia', 'Malaga']
};


const indianCities = ['Delhi', 'Mumbai', 'Goa', 'Kerala'];

function TravelPackage() {
  const [packageType, setPackageType] = useState('Domestic');
  const [checkInDate, setCheckInDate] = useState(null);
  const [checkOutDate, setCheckOutDate] = useState(null);
  const [selectedCountries, setSelectedCountries] = useState([]);
  const [selectedCity, setSelectedCity] = useState('Delhi');
  const [hotelName, setHotelName] = useState('');
  const [hotelRating, setHotelRating] = useState(5); // default value
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);
  const [childrenAges, setChildrenAges] = useState("");
  const [budget, setBudget] = useState('');
  const [mobile, setMobile] = useState('');
  const [mealPlan, setMealPlan] = useState('EP'); // default value
  const [bookingStatus, setBookingStatus] = useState('Pending'); // default value
  const [remarks, setRemarks] = useState('');
  const [customername,setCustomerName] = useState('');
  const [statusOptions, setStatusOptions] = useState([]);
  const location = useLocation();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [bookingId, setBookingId] = useState(null);
  
  useEffect(() => {
    const fetchStatusOptions = async () => {
      try {
        const response = await getStatusesByBookingType(4);
        if (response.success && response.data) {
          setStatusOptions(response.data);
          setBookingStatus(response.data[0].Stat_Desc);
        }
      } catch (error) {
        console.error('Error fetching status options:', error);
        toast.error('Failed to load booking status options');
      }
    };
    
    fetchStatusOptions();
  }, []);
  useEffect(() => {
    if (packageType === 'Domestic') {
      setSelectedCountries([]);
      setSelectedCity('Delhi');
    }
  }, [packageType]);
  console.log("this is work");
  
    // ... existing code ...
  
  // Check if we're in edit mode and populate form fields
  useEffect(() => {
    if (location.state && location.state.bookingData && location.state.isEditing) {
      const bookingData = location.state.bookingData;
      setIsEditing(true);
      setBookingId(bookingData.BookingId);
      console.log("bd",bookingData);
      
      // Set form fields based on booking data
      setPackageType(bookingData.PackageType || bookingData.package_type || 'Domestic');
      
      if (bookingData.Countries || bookingData.countries) {
        setSelectedCountries(bookingData.SelectedCountries || bookingData.selected_countries || []);
      }
      
      setSelectedCity(bookingData.City || bookingData.city || 'Delhi');
      
      // Handle dates with dayjs
      if (bookingData.CheckInDate || bookingData.check_in_date) {
        setCheckInDate(dayjs(bookingData.CheckInDate || bookingData.check_in_date));
      }
      
      if (bookingData.CheckOutDate || bookingData.check_out_date) {
        setCheckOutDate(dayjs(bookingData.CheckOutDate || bookingData.check_out_date));
      }
      
      setHotelName(bookingData.HotelName || bookingData.hotel_name || '');
      setHotelRating(bookingData.HotelRating || bookingData.hotel_rating || 5);
      setAdults(bookingData.Adults || bookingData.adults || 1);
      setChildren(bookingData.Children || bookingData.children || 0);
      setInfants(bookingData.Infants || bookingData.infants || 0);
      setChildrenAges(bookingData.ChildrenAges || bookingData.children_ages || '');
      setBudget(bookingData.Budget || bookingData.budget || '');
      setMobile(bookingData.Mobile || bookingData.mobile || '');
      setMealPlan(bookingData.MealPlan || bookingData.meal_plan || 'EP');
      setBookingStatus(bookingData.BookingStatus || bookingData.booking_status || 'Pending');
      setRemarks(bookingData.Remarks || bookingData.remarks || '');
      setCustomerName(bookingData.CustomerName || bookingData.customer_name || '');
    }
  }, [location]);
  const handleSubmit = async () => {
    try {
      const payload = {
       packageType,
        selectedCountries: packageType === 'International' ? selectedCountries : ['India'],
        selectedCity: selectedCity,
        checkInDate: checkInDate?.format('YYYY-MM-DD'),
        checkOutDate: checkOutDate?.format('YYYY-MM-DD'),
        hotelName: hotelName,
        hotelRating,
        adults,
        children,
        infants,
        childrenAges,
        budget,
        mobile,
         mealPlan,
         bookingStatus,
        remarks,
        customer_name: customername
      };
  
      let response;
      
      if (isEditing && bookingId) {
        console.log("api work");
        
        // Update existing booking
        response = await axios.put(`${apiUrl}/travel-package/bookings/${bookingId}`, payload, {
          withCredentials: true
        });
        toast.success('Travel package booking updated successfully!');
      } else {
        // Create new booking
        response = await axios.post(`${apiUrl}/travel-package/bookings`, payload, {
          withCredentials: true
        });
        toast.success('Travel package booked successfully!');
      }

      if (response.data.success) {
        // If we were editing, go back to the previous page
        // if (isEditing) {
        //   const returnPath = sessionStorage.getItem('returnToLocation') || '/';
        //   navigate(returnPath);
        //   return;
        // }
        
        // Reset all form fields to default values
        setPackageType('Domestic');
        setCheckInDate(null);
        setCheckOutDate(null);
        setSelectedCountries([]);
        setSelectedCity('Delhi');
        setHotelName('');
        setHotelRating(5);
        setAdults(1);
        setChildren(0);
        setInfants(0);
        setChildrenAges('');
        setBudget('');
        setMobile(0);
        setMealPlan('EP');
        setBookingStatus('Pending');
        setRemarks('');
        setCustomerName('');
      }
    } catch (error) {
      console.error('Booking error:', error);
      // Show validation errors if any
      if (error.response?.data?.errors) {
        const errorMessages = error.response.data.errors
          .map(err => err.msg)
          .join('\n');
          toast.error(errorMessages);
      } else {
        toast.error('Failed to book travel package. Please try again.');
      }
    }
  };
  return (
    <Container sx={{ p: 3,  mx: 'auto' }}>
    <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h6" gutterBottom>
          Travel Package Booking Form
        </Typography>
        <Grid item xs={12}>
            <TextField
              fullWidth
              label="Name"
              placeholder="Enter Customer name"
              margin="normal"
              value={customername}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </Grid>
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >Package Type</InputLabel>
              <Select
                value={packageType}
                label="Package Type"
                onChange={(e) => setPackageType(e.target.value)}
                
              >
                <MenuItem value="Domestic">Domestic</MenuItem>
                <MenuItem value="International">International</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {packageType === 'International' ? (
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel >Countries</InputLabel>
                <Select
                  multiple
                  value={selectedCountries}
                  onChange={(e) => setSelectedCountries(typeof value === 'string' ? e.target.value.split(',') : e.target.value)}
                  label="Countries"
                 
                >
                  {Object.keys(countryData).map((country) => (
                    <MenuItem key={country} value={country}>{country}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          ) : (
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel >City</InputLabel>
                <Select
                  value={selectedCity}
                  onChange={(e) => setSelectedCity(e.target.value)}
                  label="City"
                 
                >
                  {indianCities.map((city) => (
                    <MenuItem key={city} value={city}>{city}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          )}


          <LocalizationProvider dateAdapter={AdapterDayjs}>
            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Check-In Date"
                value={checkInDate}
                onChange={(newValue) => setCheckInDate(newValue)}
              
                slotProps={{
                  textField: {
                    fullWidth: true,
                    margin: "normal",
                  
                  }
                }}
              />
            </Grid>

            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Check-Out Date"
                value={checkOutDate}
                onChange={(newValue) => setCheckOutDate(newValue)}
                
                slotProps={{
                  textField: {
                    fullWidth: true,
                    margin: "normal",
                   
                  }
                }}
              />
            </Grid>
          </LocalizationProvider>

          <Grid item xs={12} sm={6}>
            <TextField
              fullWidth
              label="Hotel Name"
              value={hotelName}
              onChange={(e) => setHotelName(e.target.value)}
              margin="normal"
            />
          </Grid>

          <Grid item xs={12} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >Hotel Star Rating</InputLabel>
              <Select
                defaultValue="5"
                value={hotelRating}
                onChange={(e) => setHotelRating(e.target.value)}
                label="Hotel Star Rating"
              >
                <MenuItem value="3">3 Star</MenuItem>
                <MenuItem value="4">4 Star</MenuItem>
                <MenuItem value="5">5 Star</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Typography variant="subtitle1" sx={{ mt: 2,ml:2 ,mb:2}}>
          Number of Passengers
        </Typography>
         
          <Grid container spacing={2}>
          {['Adults', 'Children', 'Infants'].map((label, index) => (
            <Grid item xs={3} sx={{ml:2}} key={index}>
              <TextField
                label={label}
                value={label === 'Adults' ? adults : label === 'Children' ? children : infants}
                onChange={(e) => {
                  const value = parseInt(e.target.value) || 0;
                  if (label === 'Adults') setAdults(Math.max(0, value));
                  else if (label === 'Children') setChildren(Math.max(0, value));
                  else setInfants(Math.max(0, value));
                }}
                type="text"
                fullWidth
              />
            </Grid>
          ))}
        </Grid>




        
  <Grid item xs={12} sm={4}>
    <TextField
      fullWidth
      label="Age of Children (comma-separated)"
      placeholder="e.g. 4, 7"
      margin="normal"
    value={childrenAges}
    onChange={(e) => setChildrenAges(e.target.value)}
    />
  </Grid>

  <Grid item xs={12} sm={4}>
    <TextField
      fullWidth
      label="Budget (in USD)"
      placeholder="e.g. 1000 - 2000"
      margin="normal"
    value={budget}
    onChange={(e) => setBudget(e.target.value)}
    />
  </Grid>

  <Grid item xs={12} sm={4}>
    <TextField
      fullWidth
      label="Mobile Number"
      placeholder="+1 234 567 8901"
      margin="normal"
    type="tel"
    value={mobile}
    onChange={(e) => setMobile(e.target.value)}
    />
  </Grid>



          <Grid item xs={12} md={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >Meal Plan</InputLabel>
              <Select
                defaultValue="EP"
                value={mealPlan}
                onChange={(e) => setMealPlan(e.target.value)}
                label="Meal Plan"
                
              >
                <MenuItem value="EP">EP (Room Only)</MenuItem>
                <MenuItem value="CP">CP (Breakfast)</MenuItem>
                <MenuItem value="MAP">MAP (Breakfast + Dinner)</MenuItem>
                <MenuItem value="AP">AP (All Meals)</MenuItem>
              </Select>
            </FormControl>
          </Grid>

         

          <Grid item xs={12} md={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >Booking Status</InputLabel>
              <Select 
        value={bookingStatus}
        onChange={(e) => setBookingStatus(e.target.value)}
        label="Booking Status"
      >
        {statusOptions.length > 0 ? (
          statusOptions.map((status) => (
            <MenuItem key={status.Id} value={status.Stat_Desc}>
              {status.Stat_Desc}
            </MenuItem>
          ))
        ) : (
          // Fallback to hardcoded values if API fails
          [
            <MenuItem key="pending" value="Pending">Pending</MenuItem>,
            <MenuItem key="inprogress" value="InProgress">InProgress</MenuItem>,
            <MenuItem key="completed" value="Completed">Completed</MenuItem>
          ]
        )}
      </Select>
            </FormControl>
          </Grid>

          <Grid item xs={12}>
          <TextField
  fullWidth
  label="Remarks"
  value={remarks}
  onChange={(e) => setRemarks(e.target.value)}
  margin="normal"
  multiline
  rows={3}
/>


          </Grid>
        </Grid>

        <Grid container spacing={2} sx={{ mt: 2, justifyContent: 'center' }}>
  <Grid item>
    <Button variant="contained" color="error">
      Cancel
    </Button>
  </Grid>
  <Grid item>
    <Button variant="contained" color="success" onClick={handleSubmit}>
      {isEditing ? 'Update Booking' : 'Book Travel'}
    </Button>
  </Grid>
</Grid>
      </Paper>
    </Container>
  );
}

export default TravelPackage;


