import React, { useState, useEffect } from 'react';
import { Box, Typography, Grid, TextField, Button, FormControl, InputLabel, Select, MenuItem, Paper, Container } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import axios from 'axios';
import { toast } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import AddIcon from '@mui/icons-material/Add';
import PersonIcon from '@mui/icons-material/Person';
import { getStatusesByBookingType } from '../service/status';
import { useLocation, useNavigate } from 'react-router-dom';
import dayjs from 'dayjs';
const apiUrl=import.meta.env.VITE_API_URL;

// Country and city data
const countryData = {
  USA: ['New York', 'Los Angeles', 'Chicago', 'Miami', 'Las Vegas'],
  UK: ['London', 'Manchester', 'Birmingham', 'Edinburgh', 'Glasgow'],
  UAE: ['Dubai', 'Abu Dhabi', 'Sharjah', 'Ajman', 'Ras Al Khaimah'],
 
  France: ['Paris', 'Nice', 'Lyon', 'Marseille', 'Bordeaux']
 
};

// Indian cities for domestic bookings
const indianCities = ['Delhi', 'Mumbai', 'Bangalore',  'Hyderabad'];

function HotelBooking() {
  const location = useLocation();
  const navigate = useNavigate();
  const [isEditing, setIsEditing] = useState(false);
  const [bookingId, setBookingId] = useState(null);
  
  const [checkInDate, setCheckInDate] = useState(null);
  const [checkOutDate, setCheckOutDate] = useState(null);
  const [bookingType, setBookingType] = useState('Domestic');
  const [selectedCountry, setSelectedCountry] = useState('');
  const [cityOptions, setCityOptions] = useState(indianCities);
  const [selectedCity, setSelectedCity] = useState(indianCities[0]);
  const [hotelName, setHotelName] = useState('');
  const [hotelStarRating, setHotelStarRating] = useState(5);
  const [adults, setAdults] = useState(1);
  const [children, setChildren] = useState(0);
  const [infants, setInfants] = useState(0);
  const [ageOfChildren, setAgeOfChildren] = useState("");
  const [budgetRange, setBudgetRange] = useState();
  const [mealPlan, setMealPlan] = useState('EP');
  const [bookingStatus, setBookingStatus] = useState('Pending');
  const [remarks, setRemarks] = useState('');
  const [customername, setCustomerName] = useState('');
  const [printprice, setPrintPrice] = useState(0);
  const [sellingPrice, setSellingPrice] = useState(0);
  const [statusOptions, setStatusOptions] = useState([]);
  const [mobileNumber, setMobileNumber] = useState('');

  useEffect(() => {
    const fetchStatusOptions = async () => {
      try {
        const response = await getStatusesByBookingType(3);
        if (response.success && response.data) {
          setStatusOptions(response.data);
          setBookingStatus(response.data[0].Stat_Desc);
        }
      } catch (error) {
        console.error('Error fetching status options:', error);
        toast.error('Failed to load booking status options');
      }
    };
    
    fetchStatusOptions();
  }, []);

  // Update city options when country changes
  useEffect(() => {
    if (bookingType === 'International' && selectedCountry) {
      const cities = countryData[selectedCountry] || [];
      setCityOptions(cities);
      setSelectedCity(cities.length > 0 ? cities[0] : '');
    } else {
      setCityOptions(indianCities);
      setSelectedCity(indianCities[0]);
    }
  }, [selectedCountry, bookingType]);

  

  // Check if we're in edit mode and populate form fields
  useEffect(() => {
    if (location.state && location.state.bookingData && location.state.isEditing) {
      const bookingData = location.state.bookingData;
      console.log('location.state.bookingData:', bookingData);
      
      setIsEditing(true);
      setBookingId(bookingData.BookingId);
      
      // Set form fields based on booking data
      setBookingType(bookingData.BookingType || bookingData.booking_type || 'Domestic');
      setSelectedCountry(bookingData.Country || bookingData.country || '');
      setSelectedCity(bookingData.City || bookingData.city || indianCities[0]);
      
      // Handle dates with dayjs
      if (bookingData.CheckInDate || bookingData.check_in_date) {
        setCheckInDate(dayjs(bookingData.CheckInDate || bookingData.check_in_date));
      }
      
      if (bookingData.CheckOutDate || bookingData.check_out_date) {
        setCheckOutDate(dayjs(bookingData.CheckOutDate || bookingData.check_out_date));
      }
      
      setHotelName(bookingData.HotelName || bookingData.hotel_name || '');
      setHotelStarRating(bookingData.HotelStarRating || bookingData.hotel_star_rating || 5);
      setAdults(bookingData.Adults || bookingData.adults || 1);
      setChildren(bookingData.Children || bookingData.children || 0);
      setInfants(bookingData.Infants || bookingData.infants || 0);
      setAgeOfChildren(bookingData.AgeOfChildren || bookingData.age_of_children || '');
      setBudgetRange(bookingData.BudgetRange || bookingData.budget_range || '');
      setMealPlan(bookingData.MealPlan || bookingData.meal_plan || 'EP');
      setBookingStatus(bookingData.BookingStatus || bookingData.booking_status || 'Pending');
      setRemarks(bookingData.Remarks || bookingData.remarks || '');
      setSellingPrice(bookingData.SellingPrice || bookingData.selling_price || 0);
      setPrintPrice(bookingData.PrintPrice || bookingData.print_price || 0);
      setCustomerName(bookingData.CustomerName || bookingData.customername || '');
      setMobileNumber(bookingData.MobileNumber || bookingData.mobileNumber || '');
      // Update rooms state if needed
      // This is a simplified approach - you might need to adjust based on your data structure
         // Update rooms state if needed
         if (bookingData.RoomsJson) {
          try {
            // Parse the RoomsJson string if it's a string
            const roomsData = typeof bookingData.RoomsJson === 'string' 
              ? JSON.parse(bookingData.RoomsJson) 
              : bookingData.RoomsJson;
              
            if (Array.isArray(roomsData) && roomsData.length > 0) {
              // Transform the data to match the rooms state format
              const formattedRooms = roomsData.map(room => ({
                adults: room.Adults || 2,
                cwb: room.CWB || 0,
                cnb: room.CNB || 0,
                infants: room.Infants || 0
              }));
              
              setRooms(formattedRooms);
            }
          } catch (error) {
            console.error('Error parsing rooms data:', error);
            // Fallback to basic room setup if parsing fails
            setRooms([{ 
              adults: bookingData.Adults || bookingData.adults || 2, 
              cwb: 0, 
              cnb: bookingData.Children || bookingData.children || 0, 
              infants: bookingData.Infants || bookingData.infants || 0 
            }]);
          }
        }
    }
  }, [location]);
  console.log("bookingId:", bookingId);
  
  // Modify handleSubmit to handle both create and update
  const handleSubmit = async () => {
    const payload = {
      booking_type: bookingType,
      country: bookingType === 'International' ? selectedCountry : 'India',
      city: selectedCity,
      check_in_date: checkInDate ? checkInDate.format('YYYY-MM-DD') : null,
      check_out_date: checkOutDate ? checkOutDate.format('YYYY-MM-DD') : null,
      hotel_name: hotelName,
      hotel_star_rating: parseInt(hotelStarRating),
      adults: parseInt(adults),
      children: children,
      infants: parseInt(infants),
      age_of_children: ageOfChildren,
      budget_range: budgetRange,
      meal_plan: mealPlan,
      booking_status: bookingStatus,
      remarks: remarks,
      customername: customername,  // added
      printprice: parseFloat(printprice),  // added
      sellingprice: parseFloat(sellingPrice),  // added
      rooms: rooms,  // send full rooms array
      mobileNumber
    };
    
  
    try {
      let response;
      
      if (isEditing && bookingId) {
        // Update existing booking
        response = await axios.put(`${apiUrl}/hotel/bookings/${bookingId}`, payload, {
          withCredentials: true
        });
        toast.success('Hotel booking updated successfully!');
      } else {
        // Create new booking
        response = await axios.post(`${apiUrl}/hotel/bookings`, payload, {
          withCredentials: true
        });
        toast.success('Hotel booking created successfully!');
      }

      if (response.data.success) {
        // If we were editing, go back to the previous page
        if (isEditing) {
          const returnPath = sessionStorage.getItem('returnToLocation') || '/';
          navigate(returnPath);
          return;
        }
        
        // Reset form fields for new booking
        setBookingType('Domestic');
        setSelectedCountry('');
        setSelectedCity(indianCities[0]);
        setCheckInDate(null);
        setCheckOutDate(null);
        setHotelName('');
        setHotelStarRating(5);
        setAdults(1);
        setChildren(0);
        setInfants(0);
        setAgeOfChildren('');
        setBudgetRange('');
        setMealPlan('EP');
        setBookingStatus('Pending');
        setRemarks('');
      }
    } catch (error) {
      console.error('Error with hotel booking:', error);
      // Show validation errors if any
      if (error.response?.data?.errors) {
        const errorMessages = error.response.data.errors
          .map(err => err.msg)
          .join('\n');
        toast.error(errorMessages);
      } else {
        toast.error(isEditing ? 'Failed to update hotel booking. Please try again.' : 'Failed to book hotel. Please try again.');
      }
    }
  };
  
  const [rooms, setRooms] = useState([
    { adults: 2, cwb: 0, cnb: 0, infants: 0 }
  ]);

  const handleGuestChange = (roomIndex, type, value) => {
    const newRooms = [...rooms];
    newRooms[roomIndex][type] = Math.max(0, parseInt(value) || 0);
    setRooms(newRooms);
  };

  const addRoom = () => {
    setRooms([...rooms, { adults: 2, cwb: 0, cnb: 0, infants: 0 }]);
  };
  
  const getTotalPassengers = () => {
    return rooms.reduce((total, room) => {
      return total + room.adults + room.cwb + room.cnb + room.infants;
    }, 0);
  };

  return (
    <Container sx={{ p: 3,  mx: 'auto',  }}>
       <Paper elevation={3} sx={{ p: 4 }}>
        <Typography variant="h6" gutterBottom>
          Hotel Booking Form
        </Typography>

        {/* Booking Type */}
        <Grid container spacing={2}>
        <Grid item xs={6}>
            <TextField
              fullWidth
              label="Name"
              placeholder="Enter Customer name"
              margin="normal"
              value={customername}
              onChange={(e) => setCustomerName(e.target.value)}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Mobile Number"
              placeholder="Enter mobile number"
              margin="normal"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
            />
          </Grid>
          </Grid>
       
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >Booking Type</InputLabel>
              <Select
                value={bookingType}
                onChange={(e) => {
                  setBookingType(e.target.value);
                  if (e.target.value === 'Domestic') {
                    setSelectedCountry('');
                    setCityOptions(indianCities);
                  }
                }}
                label="Booking Type"
              
              >
                <MenuItem value="Domestic">Domestic</MenuItem>
                <MenuItem value="International">International</MenuItem>
              </Select>
            </FormControl>
          </Grid>

          {/* Country Selection - Only shown for International bookings */}
          {bookingType === 'International' && (
            <Grid item xs={12} sm={6}>
              <FormControl fullWidth margin="normal">
                <InputLabel >Country</InputLabel>
                <Select
                  value={selectedCountry}
                  onChange={(e) => setSelectedCountry(e.target.value)}
                  label="Country"
                
                >
                  {Object.keys(countryData).map((country) => (
                    <MenuItem key={country} value={country}>{country}</MenuItem>
                  ))}
                </Select>
              </FormControl>
            </Grid>
          )}

          {/* City */}
          <Grid item xs={12} sm={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel >City</InputLabel>
              <Select
                value={selectedCity}
                onChange={(e) => setSelectedCity(e.target.value)}
                label="City"
                
                disabled={bookingType === 'International' && !selectedCountry}
              >
                {cityOptions.map((city) => (
                  <MenuItem key={city} value={city}>{city}</MenuItem>
                ))}
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* Check-in and Check-out Dates */}
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          <Grid container spacing={2}>
            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Check-In Date"
                value={checkInDate}
                onChange={(newValue) => setCheckInDate(newValue)}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    margin: 'normal',
                   
                  },
                }}
              />
            </Grid>
            <Grid item xs={12} sm={6}>
              <DatePicker
                label="Check-Out Date"
                value={checkOutDate}
                onChange={(newValue) => setCheckOutDate(newValue)}
                slotProps={{
                  textField: {
                    fullWidth: true,
                    margin: 'normal',
                 
                  },
                }}
              />
            </Grid>
          </Grid>
        </LocalizationProvider>

        {/* Hotel Details */}
        <Grid container spacing={2}>
          <Grid item xs={12} sm={6}>
          <TextField
  fullWidth
  label="Hotel Name"
  margin="normal"
  value={hotelName}
  onChange={(e) => setHotelName(e.target.value)}
/>

          </Grid>
          <Grid item xs={12} sm={6}>
          <FormControl fullWidth margin="normal">
  <InputLabel>Hotel Star Rating</InputLabel>
  <Select
    value={hotelStarRating}
    onChange={(e) => setHotelStarRating(e.target.value)}
    label="Hotel Star Rating"
  >
    <MenuItem value={3}>3 Star</MenuItem>
    <MenuItem value={4}>4 Star</MenuItem>
    <MenuItem value={5}>5 Star</MenuItem>
  </Select>
</FormControl>

          </Grid>
        </Grid>

        {/* Number of Guests */}
        <Typography variant="subtitle1" sx={{ mt: 2 }}>
          Number of Guests
        </Typography>
        {/* <Grid container spacing={2}>
          {['Adults', 'Children', 'Infants'].map((label, index) => (
            <Grid item xs={4} key={index}>
              <TextField
                label={label}
                value={label === 'Adults' ? adults : label === 'Children' ? children : infants}
                onChange={(e) => {
                  const value = parseInt(e.target.value) || 0;
                  if (label === 'Adults') setAdults(Math.max(0, value));
                  else if (label === 'Children') setChildren(Math.max(0, value));
                  else setInfants(Math.max(0, value));
                }}
                type="text"
                fullWidth
              />
            </Grid>
          ))}
        </Grid> */}
         {rooms.map((room, roomIndex) => (
          <Box key={roomIndex} sx={{ mb: 2 }}>
            <Typography variant="subtitle1" sx={{ mb: 1 }}>
              Room {roomIndex + 1}
            </Typography>
            <Grid container spacing={2}>
              <Grid item xs={3}>
                <FormControl fullWidth>
                  <InputLabel>Adult/s</InputLabel>
                  <Select
                    value={room.adults}
                    label="Adult/s"
                    onChange={(e) => handleGuestChange(roomIndex, 'adults', e.target.value)}
                  >
                    {[...Array(10)].map((_, i) => (
                      <MenuItem key={i} value={i + 1}>{i + 1}</MenuItem>
                    ))}
                  </Select>
                  <Typography variant="caption" color="textSecondary">
                    + 12 yrs
                  </Typography>
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <FormControl fullWidth>
                  <InputLabel>CWB</InputLabel>
                  <Select
                    value={room.cwb}
                    label="CWB"
                    onChange={(e) => handleGuestChange(roomIndex, 'cwb', e.target.value)}
                  >
                    {[...Array(11)].map((_, i) => (
                      <MenuItem key={i} value={i}>{i}</MenuItem>
                    ))}
                  </Select>
                  <Typography variant="caption" color="textSecondary">
                    {'< 12 yrs'}
                  </Typography>
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <FormControl fullWidth>
                  <InputLabel>CNB</InputLabel>
                  <Select
                    value={room.cnb}
                    label="CNB"
                    onChange={(e) => handleGuestChange(roomIndex, 'cnb', e.target.value)}
                  >
                    {[...Array(11)].map((_, i) => (
                      <MenuItem key={i} value={i}>{i}</MenuItem>
                    ))}
                  </Select>
                  <Typography variant="caption" color="textSecondary">
                    {'< 12 yrs'}
                  </Typography>
                </FormControl>
              </Grid>
              <Grid item xs={3}>
                <FormControl fullWidth>
                  <InputLabel>Infant/s</InputLabel>
                  <Select
                    value={room.infants}
                    label="Infant/s"
                    onChange={(e) => handleGuestChange(roomIndex, 'infants', e.target.value)}
                  >
                    {[...Array(11)].map((_, i) => (
                      <MenuItem key={i} value={i}>{i}</MenuItem>
                    ))}
                  </Select>
                  <Typography variant="caption" color="textSecondary">
                    {'< 2 yrs'}
                  </Typography>
                </FormControl>
              </Grid>
            </Grid>
          </Box>
        ))}

<Box sx={{ display: 'flex', justifyContent: "flex-start", alignItems: 'center', mt: 2, mb: 3, }}>
          <Button
            variant="outlined"
            onClick={addRoom}
            startIcon={<AddIcon />}
            sx={{ mr: 2 }}
          >
            Add Another Room
          </Button> 
          <Typography variant="subtitle1" sx={{ display: 'flex', alignItems: 'center' }}>
            <PersonIcon sx={{ mr: 1 }} />
            Total Passengers: {getTotalPassengers()}
          </Typography>
        </Box>
       
        {/* Additional Details */}
        <Grid container spacing={2}>
          
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Print Price"
            type="number"
           value={printprice}
            onChange={(e) => setPrintPrice(e.target.value)}
            InputProps={{
              startAdornment: <Typography>₹</Typography>
            }}
          />
        </Grid>
        <Grid item xs={6}>
          <TextField
            fullWidth
            label="Selling Price"
            type="number"
            value={sellingPrice}
            onChange={(e) => setSellingPrice(e.target.value)}
            InputProps={{
              startAdornment: <Typography>₹</Typography>
            }}
          />
        </Grid>
  <Grid item xs={12} md={6}>
    <TextField
      fullWidth
      label="Age of Children (comma-separated)"
      placeholder="e.g. 5, 9"
      value={ageOfChildren}
      onChange={(e) => setAgeOfChildren(e.target.value)}
      margin="normal"
    />
  </Grid>
  <Grid item xs={12} md={6}>
    <TextField
      fullWidth
      label="Budget Range (in USD)"
      placeholder="e.g. 500-1000"
      value={budgetRange}
      onChange={(e) => setBudgetRange(e.target.value)}
      margin="normal"
    />
  </Grid>
</Grid>



        {/* Meal Plan */}
        <Grid container spacing={2}>
  <Grid item xs={12} sm={6}>
    <FormControl fullWidth margin="normal">
      <InputLabel>Meal Plan</InputLabel>
      <Select
        value={mealPlan}
        onChange={(e) => setMealPlan(e.target.value)}
        label="Meal Plan"
      >
        <MenuItem value="EP">EP (Room Only)</MenuItem>
        <MenuItem value="CP">CP (Breakfast)</MenuItem>
        <MenuItem value="MAP">MAP (Breakfast & Dinner)</MenuItem>
        <MenuItem value="AP">AP (All Meals)</MenuItem>
      </Select>
    </FormControl>
  </Grid>
  <Grid item xs={12} sm={6}>
    <FormControl fullWidth margin="normal">
      <InputLabel>Booking Status</InputLabel>
      <Select 
        value={bookingStatus}
        onChange={(e) => setBookingStatus(e.target.value)}
        label="Booking Status"
      >
        {statusOptions.length > 0 ? (
          statusOptions.map((status) => (
            <MenuItem key={status.Id} value={status.Stat_Desc}>
              {status.Stat_Desc}
            </MenuItem>
          ))
        ) : (
          // Fallback to hardcoded values if API fails
          [
            <MenuItem key="pending" value="Pending">Pending</MenuItem>,
            <MenuItem key="inprogress" value="InProgress">InProgress</MenuItem>,
            <MenuItem key="completed" value="Completed">Completed</MenuItem>
          ]
        )}
      </Select>
    </FormControl>
  </Grid>
</Grid>


        {/* Remarks */}
        <TextField
  fullWidth
  label="Remarks"
  value={remarks}
  onChange={(e) => setRemarks(e.target.value)}
  margin="normal"
  multiline
  rows={3}
/>


        {/* Submit Button */}
        <Grid container spacing={2} sx={{ mt: 2, justifyContent: 'center' }}>
  <Grid item>
    <Button variant="contained" color="error">
      Cancel
    </Button>
  </Grid>
  <Grid item>
  <Button variant="contained" color="success" onClick={handleSubmit}>
    {isEditing ? 'Update Booking' : 'Book Hotel'}
  </Button>

  </Grid>
</Grid>
        </Paper >
    </Container>
  );
}

export default HotelBooking;