import React, { useState } from 'react';
import {
  Box, Button, Typography, Grid, TextField, Container, Paper,
  FormControl, InputLabel, Select, MenuItem,
  FormControlLabel,
  Switch
} from '@mui/material';
import { DatePicker, LocalizationProvider } from '@mui/x-date-pickers';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';
import AddIcon from '@mui/icons-material/Add';
import { toast } from 'react-toastify';
import EditIcon from '@mui/icons-material/Edit';
const FlightBookingForm = ({
  initialData = {},
  onSubmit,
  submitLabel = "Book Flight",
  readOnly= false,
  showCancel = true,
  isUpdateQuery,
  onCancel
}) => {
  const [tripType, setTripType] = useState(initialData.tripType || 'Single');
  const [fareType, setFareType] = useState(initialData.fareType || 'Normal');
  const [departureDate, setDepartureDate] = useState(initialData.departureDate || null);
  const [returnDate, setReturnDate] = useState(initialData.returnDate || null);
  const [segment1Date, setSegment1Date] = useState(initialData.segment1Date || null);
  const [segment2Date, setSegment2Date] = useState(initialData.segment2Date || null);
  const [segment3Date, setSegment3Date] = useState(initialData.segment3Date || null);
  const [adults, setAdults] = useState(initialData.adults || 1);
  const [children, setChildren] = useState(initialData.children || 0);
  const [infants, setInfants] = useState(initialData.infants || 0);
  const [childrenAge, setChildrenAge] = useState(initialData.childrenAges || '');
  const [mobileNumber, setMobileNumber] = useState(initialData.mobileNumber || '');
  const [customername, setCustomerName] = useState(initialData.customername || '');
  const [bookingStatus, setBookingStatus] = useState(initialData.bookingStatus || 'Pending');
  const [cityPairs, setCityPairs] = useState(initialData.cityPairs || [{ from: '', to: '' }]);
  const [remarks, setRemarks] = useState(initialData.remarks || '');
   // Add a state to track edit mode (opposite of readOnly)
   const [isEditMode, setIsEditMode] = useState(readOnly);
  
   // Update the toggle function to set both states
   const toggleEditMode = () => {
     setIsEditMode(!isEditMode);
   };

  const datePickerProps = {
    slotProps: {
      textField: {
        fullWidth: true,
        margin: 'normal',
      },
    },
  };

  const addCityPair = () => {
    const lastPair = cityPairs[cityPairs.length - 1];
    setCityPairs([...cityPairs, { from: lastPair.to, to: '' }]);
  };

  const handleCityChange = (index, field, value) => {
    const newPairs = [...cityPairs];
    newPairs[index][field] = value;
    setCityPairs(newPairs);
  };

//   const handleSubmit = async () => {
//     const data = {
//       tripType,
//       fareType,
//       departureDate,
//       returnDate,
//       segment1Date,
//       segment2Date,
//       segment3Date,
//       passengers: { adults, children, infants, childrenAge },
//       mobileNumber,
//       customername,
//       bookingStatus,
//       cityPairs,
//       remarks: document.querySelector('[name="remarks"]')?.value || ''
//     };

//     try {
//       await onSubmit(data);
//       toast.success(`${submitLabel} successful!`);
//     } catch (err) {
//       toast.error("Error submitting booking.");
//     }
//   };
const handleSubmit = async (queryUpdateOnly = false) => {
    const data = {
      tripType,
      fareType,
      departureDate,
      returnDate,
      segment1Date,
      segment2Date,
      segment3Date,
      passengers: { adults, children, infants, childrenAge },
      mobileNumber,
      customername,
      bookingStatus,
      cityPairs,
      remarks,
      queryUpdateOnly
    };

    try {
      await onSubmit(data);
      toast.success(`${queryUpdateOnly ? 'Query Updated' : submitLabel} successful!`);
    } catch (err) {
      toast.error(queryUpdateOnly ? "Error updating query." : "Error submitting booking.");
    }
  };


  return (
    <Container sx={{ p: 1}}>
      <Paper elevation={3} sx={{ p: 2 }}>
      <Box display="flex" justifyContent="flex-start" alignItems="center" mb={2}>
          <Typography variant="h6" gutterBottom>
            Flight Booking Form
          </Typography> <br />
          <FormControlLabel
            control={
              <Switch 
                checked={isEditMode} 
                onChange={toggleEditMode} 
                color="primary" 
              />
            }
            label={isEditMode ? "Editing" : "View Only"}
          />
        </Box>

        <TextField
          fullWidth
          label="Name"
          value={customername}
          onChange={(e) => setCustomerName(e.target.value)}
          disabled={!isEditMode}
        />

        {/* Trip & Fare Type */}
        <Grid container spacing={2}>
          <Grid item xs={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel>Trip Type</InputLabel>
              <Select value={tripType} onChange={(e) => setTripType(e.target.value)} disabled={readOnly}>
                <MenuItem value="Single">Single</MenuItem>
                <MenuItem value="Roundtrip">Roundtrip</MenuItem>
                <MenuItem value="Multicity">Multicity</MenuItem>
              </Select>
            </FormControl>
          </Grid>
          <Grid item xs={6}>
            <FormControl fullWidth margin="normal">
              <InputLabel>Fare Type</InputLabel>
              <Select value={fareType} onChange={(e) => setFareType(e.target.value)} disabled={readOnly}>
                <MenuItem value="Normal">Normal</MenuItem>
                <MenuItem value="Refundable">Refundable</MenuItem>
                <MenuItem value="Non-Refundable">Non-Refundable</MenuItem>
              </Select>
            </FormControl>
          </Grid>
        </Grid>

        {/* City Pairs */}
        {cityPairs.map((pair, index) => (
          <Grid container spacing={2} key={index}>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label={`From ${index + 1}`}
                value={pair.from}
                onChange={(e) => handleCityChange(index, 'from', e.target.value)}
                disabled={!isEditMode}
              />
            </Grid>
            <Grid item xs={6}>
              <TextField
                fullWidth
                label={`To ${index + 1}`}
                value={pair.to}
                onChange={(e) => handleCityChange(index, 'to', e.target.value)}
                disabled={!isEditMode}
              />
            </Grid>
          </Grid>
        ))}
        {tripType === 'Multicity' && cityPairs[cityPairs.length - 1].to && !readOnly && (
          <Button onClick={addCityPair} startIcon={<AddIcon />} sx={{ mt: 2 }}>
            Add City
          </Button>
        )}

        {/* Date Pickers */}
        <LocalizationProvider dateAdapter={AdapterDayjs}>
          {tripType === 'Single' && (
            <DatePicker
              label="Departure Date"
              value={departureDate}
              onChange={(newValue) => setDepartureDate(newValue)}
              disabled={!isEditMode}
              {...datePickerProps}
            />
          )}
          {tripType === 'Roundtrip' && (
            <Grid container spacing={2}>
              <Grid item xs={6}>
                <DatePicker
                  label="Departure Date"
                  value={departureDate}
                  onChange={(newValue) => setDepartureDate(newValue)}
                  disabled={!isEditMode}
                  {...datePickerProps}
                />
              </Grid>
              <Grid item xs={6}>
                <DatePicker
                  label="Return Date"
                  value={returnDate}
                  onChange={(newValue) => setReturnDate(newValue)}
                  disabled={!isEditMode}
                  {...datePickerProps}
                />
              </Grid>
            </Grid>
          )}
          {tripType === 'Multicity' && (
            <Grid container spacing={2}>
              {[segment1Date, segment2Date, segment3Date].map((date, index) => (
                <Grid item xs={4} key={index}>
                  <DatePicker
                    label={`Segment ${index + 1}`}
                    value={date}
                    onChange={(newValue) => {
                      if (index === 0) setSegment1Date(newValue);
                      if (index === 1) setSegment2Date(newValue);
                      if (index === 2) setSegment3Date(newValue);
                    }}
                    disabled={!isEditMode}
                    {...datePickerProps}
                  />
                </Grid>
              ))}
            </Grid>
          )}
        </LocalizationProvider>

        {/* Passenger Info */}
        <Grid container spacing={2} sx={{ mt: 1 }}>
          {['Adults', 'Children', 'Infants'].map((label, index) => (
            <Grid item xs={4} key={index}>
              <TextField
                label={label}
                type="number"
                value={label === 'Adults' ? adults : label === 'Children' ? children : infants}
                onChange={(e) => {
                  const value = parseInt(e.target.value) || 0;
                  if (label === 'Adults') setAdults(value);
                  else if (label === 'Children') setChildren(value);
                  else setInfants(value);
                }}
                disabled={!isEditMode}
                fullWidth
              />
            </Grid>
          ))}
        </Grid>

        <Grid container spacing={2} sx={{ mt: 1 }}>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Children Age"
              value={childrenAge}
              onChange={(e) => setChildrenAge(e.target.value)}
              disabled={!isEditMode}
            />
          </Grid>
          <Grid item xs={6}>
            <TextField
              fullWidth
              label="Mobile Number"
              value={mobileNumber}
              onChange={(e) => setMobileNumber(e.target.value)}
              disabled={!isEditMode}
            />
          </Grid>
        </Grid>

        <FormControl fullWidth margin="normal">
          <InputLabel>Booking Status</InputLabel>
          <Select value={bookingStatus} onChange={(e) => setBookingStatus(e.target.value)} disabled={readOnly}>
            <MenuItem value="Pending">Pending</MenuItem>
            <MenuItem value="InProgress">InProgress</MenuItem>
            <MenuItem value="Completed">Completed</MenuItem>
          </Select>
        </FormControl>

        <TextField
          fullWidth
          name="remarks"
          value={remarks}
          onChange={(e) => setRemarks(e.target.value)}
          label="Remarks"
          multiline
          rows={3}
          margin="normal"
          disabled={!isEditMode}
        />

<Grid container spacing={2} sx={{ mt: 2 }}>
          {showCancel && (
            <Grid item>
              <Button variant="outlined" onClick={onCancel || (() => window.history.back())}>
                Cancel
              </Button>
            </Grid>
          )}
          
          {!isEditMode ? (
            // Show both buttons in edit mode
            <>
              <Grid item>
                <Button 
                  variant="outlined" 
                  color="primary" 
                  onClick={() => handleSubmit(true)}
                >
                  Update Query Only
                </Button>
              </Grid>
            
            </>
          ) : (
            // Show edit button in read-only mode
            <Grid item>
            <Button 
              variant="contained" 
              color="success" 
              onClick={() => handleSubmit(false)}
            >
              {submitLabel}
            </Button>
          </Grid>
          )}
        </Grid>
      </Paper>
    </Container>
  );
};

export default FlightBookingForm;
