import React, { useEffect, useState } from 'react';
import FlightBookingForm from '../components/FlightBookingForm';
import { getBookingById, updateBooking } from '../api/flightBookingAPI';
import { useParams } from 'react-router-dom';

const EditFlightBooking = () => {
  const { id } = useParams();
  const [bookingData, setBookingData] = useState(null);

  useEffect(() => {
    getBookingById(id).then(setBookingData);
  }, [id]);

  return bookingData ? (
    <FlightBookingForm
      initialData={bookingData}
      onSubmit={(data) => updateBooking(id, data)}
      submitLabel="Update Booking"
    />
  ) : (
    <div>Loading...</div>
  );
};

export default EditFlightBooking;
