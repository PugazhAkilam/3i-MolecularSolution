import React from 'react';
import FlightBookingForm from '../components/FlightBookingForm';
import { createBooking } from '../api/flightBookingAPI';

const CreateFlightBooking = () => {
  return (
    <FlightBookingForm
      onSubmit={createBooking}
      submitLabel="Book Flight"
    />
  );
};

export default CreateFlightBooking;
