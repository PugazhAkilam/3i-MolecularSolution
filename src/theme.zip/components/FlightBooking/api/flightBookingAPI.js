import axios from 'axios';

const apiUrl = import.meta.env.VITE_API_URL;

export const createBooking = (data) =>
  axios.post(`${apiUrl}/flight/bookings`, data, { withCredentials: true });

export const getBookingById = (id) =>
  axios.get(`${apiUrl}/flight/bookings/${id}`, { withCredentials: true }).then(res => res.data);

export const updateBooking = (id, data) =>
  axios.put(`${apiUrl}/flight/bookings/${id}`, data, { withCredentials: true });
