import React from 'react';
import { Box, Button, TextField, ToggleButton, ToggleButtonGroup } from '@mui/material';
import { DatePicker } from '@mui/x-date-pickers/DatePicker';
import { LocalizationProvider } from '@mui/x-date-pickers/LocalizationProvider';
import { AdapterDayjs } from '@mui/x-date-pickers/AdapterDayjs';

const FilterControls = ({
  bookingType,
  setBookingType,
  startDate,
  setStartDate,
  endDate,
  setEndDate,
  searchQuery,
  setSearchQuery,
  handleSearch,
  handleClear
}) => {
  return (
    <Box sx={{ display: 'flex', gap: 2, alignItems: 'center' }}>
      <ToggleButtonGroup
        value={bookingType}
        exclusive
        onChange={(e, newValue) => setBookingType(newValue || 'all')}
        aria-label="booking type"
      >
        <ToggleButton value="all">All</ToggleButton>
        <ToggleButton value="flight">Flight</ToggleButton>
        <ToggleButton value="hotel">Hotel</ToggleButton>
        <ToggleButton value="travelpackage">Travel</ToggleButton>
        <ToggleButton value="visa">Visa</ToggleButton>
      </ToggleButtonGroup>

      <LocalizationProvider dateAdapter={AdapterDayjs}>
        <DatePicker
          label="Start Date"
          value={startDate}
          onChange={setStartDate}
          renderInput={(params) => <TextField {...params} />}
        />
        <DatePicker
          label="End Date"
          value={endDate}
          onChange={setEndDate}
          renderInput={(params) => <TextField {...params} />}
        />
      </LocalizationProvider>

      <Button variant="contained" onClick={handleSearch}>
        Search
      </Button>
      <Button 
        variant='outlined' 
        onClick={handleClear} 
        title="Double click to clear dates and refresh data"
      >
        Clear Date
      </Button>
    </Box>
  );
};

export default FilterControls;