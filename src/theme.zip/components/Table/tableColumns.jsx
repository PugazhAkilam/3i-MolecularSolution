import RoomIcon from '@mui/icons-material/Room';

// Common utility function for date formatting
const formatDate = (value) => {
    if (!value) return '';
    try {
      const date = new Date(value);
      return date.toLocaleDateString();
    } catch {
      return value;
    }
  };
  
  // Common utility for null handling
  const displayWithFallback = (value, fallback = 'NUll') => {
    return value && value.trim && value.trim() !== '' ? value : fallback;
  };
  
  // Common Columns
  export const createCommonColumns = (rows, handleAddToQuery,hasInProcessQuery) => {
    return {
      indexColumn: {
        field: 'index',
        headerName: 'S.No',
        width: 100,
        renderCell: (params) => rows.indexOf(params.row) + 1
      },
      addToQueryColumn: {
        field: 'addToQuery',
        headerName: 'Add to Pick',
        width: 150,
        sortable: false,
        filterable: false,
        renderCell: (params) => (
          <button
            style={{
              padding: '6px 12px',
              backgroundColor: '#1976d2',
              color: 'white',
              border: 'none',
              borderRadius: '4px',
              cursor: 'pointer'
            }}
            onClick={() => handleAddToQuery(params.row)}
          >
            Add to Pick
          </button>
        )
      },
      sourceTypeColumn: {
        field: 'SourceType',
        headerName: 'Booking Type',
        width: 130
      },
      customername:{
        field: 'customername',
        headerName: 'Customer Name',
        width: 150,
        renderCell: (params) => displayWithFallback(params.value)
      },
      mobileColumn: {
        field: 'MobileNumber',
        headerName: 'Mobile',
        width: 130,
        renderCell: (params) => displayWithFallback(params.value)
      },
      userCodeColumn: {
        field: 'UserName',
        headerName: 'Submited By',
        width: 130,
        renderCell: (params) => displayWithFallback(params.value)
      },
      createdOnColumn: {
        field: 'CreatedOn',
        headerName: 'Created Date',
        width: 150,
        renderCell: (params) => formatDate(params.row.CreatedOn)
      },
      bookingStatusColumn: {
        field: 'BookingStatus',
        headerName: 'Booking Status',
        width: 150,
        renderCell: (params) => displayWithFallback(params.value)
      },
      // Add other common columns...
      budgetColumn: {
        field: 'Budget',
        headerName: 'Budget',
        width: 200,
        renderCell: (params) => displayWithFallback(params.value)
      },
      // Passenger columns
      adultsColumn: {
        field: 'Adults',
        headerName: 'Adults',
        width: 100,
        renderCell: (params) => displayWithFallback(params.value)
      },
      childrenColumn: {
        field: 'Children',
        headerName: 'Children',
        width: 100,
        renderCell: (params) => displayWithFallback(params.value)
      },
      infantsColumn: {
        field: 'Infants',
        headerName: 'Infants',
        width: 100,
        renderCell: (params) => displayWithFallback(params.value)
      },
      childrenAgesColumn: {
        field: 'ChildrenAges',
        headerName: 'Children Ages',
        width: 150,
        renderCell: (params) => displayWithFallback(params.value)
      },
      remarksColumn: {
        field: 'Remarks',
        headerName: 'Remarks',
        width: 200,
        renderCell: (params) => displayWithFallback(params.value)
      }
    };
  };
  
  // Date column creator
  export const createDateColumn = (field, headerName) => ({
    field,
    headerName,
    width: 130,
    renderCell: (params) => formatDate(params.row[field])
  });
  
  // Flight specific columns
  export const createFlightColumns = (handleOpenDialogBox) => ({
    tripTypeColumn: {
      field: 'TripType',
      headerName: 'Trip Type',
      width: 130
    },
    fareTypeColumn: {
      field: 'FareType',
      headerName: 'Fare Type',
      width: 130
    },
    fromToAddressColumn: {
      field: 'fromToAddress',
      headerName: 'From-To Address',
      width: 150,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <div
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center'
          }}
          onClick={() => handleOpenDialogBox(params.row)}
        >
          <span role="img" aria-label="address" style={{ fontSize: '1.2rem' }}>📍</span>
        </div>
      )},
    departureDate: createDateColumn('DepartureDate', 'Departure Date'),
    returnDate: createDateColumn('ReturnDate', 'Return Date'),
    segment1Date: createDateColumn('Segment1Date', 'Segment 1 Date'),
    segment2Date: createDateColumn('Segment2Date', 'Segment 2 Date'),
    segment3Date: createDateColumn('Segment3Date', 'Segment 3 Date')
  });
  
  // Hotel specific columns
  export const createHotelColumns = (handleOpenDialogBox) => ({
    countriesColumn: {
      field: 'Countries',
      headerName: 'Country',
      width: 130
    },
    mealplanColumn: {
      field: 'MealPlan',
      headerName: 'Meal Plan',
      width: 200,
      renderCell: (params) => displayWithFallback(params.value)
    },
    checkInDateColumn: createDateColumn('CheckInDate', 'Check In'),
    checkOutDateColumn: createDateColumn('CheckOutDate', 'Check Out'),
    cityColumn: {
      field: 'City',
      headerName: 'City',
      width: 130
    },
    hotelNameColumn: {
      field: 'HotelName',
      headerName: 'Hotel Name',
      width: 150
    },
    rooms : {
      field: 'fromToAddress',
      headerName: 'From-To Address',
      width: 150,
      sortable: false,
      filterable: false,
      renderCell: (params) => (
        <div
          style={{
            cursor: 'pointer',
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            gap: '4px',
          }}
          onClick={() => handleOpenDialogBox(params.row)}
        >
          <RoomIcon style={{ fontSize: '1.2rem', color: '#1976d2' }} />
          <span style={{ fontSize: '1rem' }}>Room</span>
        </div>
      ),
    },
    hotelRatingColumn: {
      field: 'HotelRating',
      headerName: 'Rating',
      width: 100,
      renderCell: (params) => `${params.value} star` || 'NUll'
    }
  });
  
  // Travel package specific columns
  export const createTravelPackageColumns = () => ({
    packageTypeColumn: {
      field: 'PackageType',
      headerName: 'BookingType',
      width: 130
    },
    travelCountriesColumn: {
      field: 'Countries',
      headerName: 'Countries',
      width: 200,
      renderCell: (params) => displayWithFallback(params.value)
    }
  });
  
  // Visa specific columns
  export const createVisaColumns = () => ({
    visaCountriesColumn: {
      field: 'Countries',
      headerName: 'Countries',
      width: 200,
      renderCell: (params) => displayWithFallback(params.value)
    },
    visaTypeColumn: {
      field: 'VisaType',
      headerName: 'Visa Type',
      width: 130,
      renderCell: (params) => displayWithFallback(params.value)
    },
    travelDate: createDateColumn('DepartureDate', 'Travel Date')
  });
  
  // Column group generator
  export const getColumnsForSourceType = (sourceType, rows, handleAddToQuery, handleOpenDialogBox,hasInProcessQuery) => {
    const common = createCommonColumns(rows, handleAddToQuery, hasInProcessQuery);
    const flight = createFlightColumns(handleOpenDialogBox);
    const hotel = createHotelColumns(handleOpenDialogBox);
    const travel = createTravelPackageColumns();
    const visa = createVisaColumns();
    
    const commonColumnsList = [
      common.indexColumn,
      common.addToQueryColumn,
      common.userCodeColumn,
      common.sourceTypeColumn,
      common.customername,
      common.mobileColumn,
      common.bookingStatusColumn,
      common.budgetColumn,
      common.adultsColumn,
      common.childrenColumn,
      common.infantsColumn,
      common.childrenAgesColumn,
      common.createdOnColumn,
      common.remarksColumn
    ];
  
    switch (sourceType) {
      case 'flight':
        return [
          common.indexColumn,
          common.addToQueryColumn,
          common.userCodeColumn,
        
          common.sourceTypeColumn,
          common.customername,
          common.mobileColumn,
          flight.tripTypeColumn,
          flight.fromToAddressColumn, // Add this line to include the new column
          flight.fareTypeColumn,
          common.bookingStatusColumn,
          common.adultsColumn,
          common.childrenColumn,
          common.infantsColumn,
          common.childrenAgesColumn,
          flight.departureDate,
          flight.returnDate,
          flight.segment1Date,
          flight.segment2Date,
          flight.segment3Date,
          common.createdOnColumn,
          common.remarksColumn
        ];
  
      case 'hotel':
        return [
          common.indexColumn,
          common.addToQueryColumn,
          common.userCodeColumn,
          common.sourceTypeColumn,
          common.customername,
          common.mobileColumn,
          travel.packageTypeColumn,
          hotel.countriesColumn,
          hotel.cityColumn,
          common.bookingStatusColumn,
          hotel.hotelNameColumn,
          hotel.rooms,
          hotel.hotelRatingColumn,
          common.adultsColumn,
          common.childrenColumn,
          common.infantsColumn,
          common.childrenAgesColumn,
          common.budgetColumn,
          hotel.checkInDateColumn,
          hotel.checkOutDateColumn,
          hotel.mealplanColumn,
          common.createdOnColumn,
          common.remarksColumn
        ];
  
      case 'travelpackage':
        return [
          common.indexColumn,
          common.addToQueryColumn,
          common.userCodeColumn,
          common.sourceTypeColumn,
          common.customername,
          common.mobileColumn,
          travel.packageTypeColumn,
          travel.travelCountriesColumn,
          hotel.cityColumn,
          common.adultsColumn,
          common.childrenColumn,
          common.infantsColumn,
          hotel.hotelRatingColumn,
          common.childrenAgesColumn,
          common.budgetColumn,
          hotel.checkInDateColumn,
          hotel.checkOutDateColumn,
          hotel.mealplanColumn,
          common.bookingStatusColumn,
          common.createdOnColumn,
          common.remarksColumn
        ];
  
      case 'visa':
        return [
          common.indexColumn,
          common.addToQueryColumn,
          common.userCodeColumn,
          common.sourceTypeColumn,
          common.customername,
          common.mobileColumn,
          visa.visaCountriesColumn,
          visa.visaTypeColumn,
          common.bookingStatusColumn,
          visa.travelDate,
          common.adultsColumn,
          common.childrenColumn,
          common.infantsColumn,
          common.childrenAgesColumn,
          common.createdOnColumn,
          common.remarksColumn
        ];
  
      default:
        return commonColumnsList;
    }
  };