import axios from 'axios';

const apiUrl = import.meta.env.VITE_API_URL;

// Fetch all statuses
export const getAllStatuses = () => 
  axios.get(`${apiUrl}/status/statuses`, { withCredentials: true })
    .then(res => res.data);

// Fetch statuses by booking type ID
export const getStatusesByBookingType = (bookingTypeId) => 
  axios.get(`${apiUrl}/status/statuses/${bookingTypeId}`, { withCredentials: true })
    .then(res => res.data);


    // insert status
export const insertStatus = (bookingTypeId) => 
  axios.get(`${apiUrl}/status/statuses/${bookingTypeId}`, { withCredentials: true })
    .then(res => res.data);


    // Edit status by ID
export const editStatus = (id, statusData) =>
  axios.put(`${apiUrl}/status/statuses/${id}`, statusData, { withCredentials: true })
    .then(res => res.data);


// Delete status by ID
export const deleteStatus = (id) =>
  axios
    .delete(`${apiUrl}/status/statuses/${id}`, {
      withCredentials: true,
    })
    .then((res) => res.data);


    //insert new location
export const insertLocation = (locationData) =>
  axios.post(`${apiUrl}/status/locations`, locationData, { withCredentials: true })
    .then(res => res.data);


    //get location by booking type

export const getLocationsByBookingType=(locationData)=>
  axios.get(`${apiUrl}/status/locations`,{ params:locationData,withCredentials:true })
  .then(res=>res.data);

  //edit location
export const updateLocations=(id,locationData)=>
  axios.put(`${apiUrl}/status/locations/${id}`,locationData,{withCredentials: true})
  .then(res=>res.data);

  //delete location by id
export const deleteLocation=(id)=>
  axios.delete(`${apiUrl}/status/locations/${id}`,{withCredentials:true})
  .then(res=>res.data);

  //add region
export const addRegion=(regionData)=>
  axios.post(`${apiUrl}/status/regions`,regionData,{withCredentials:true})
  .then(res=>res.data);

  //get all regions
export const getAllRegions=()=>
  axios.get(`${apiUrl}/status/regions`,{withCredentials:true})
  .then(res=>res.data);

  //edit region by id
export const updateRegion=(id,regionData)=>
  axios.put(`${apiUrl}/status/regions/${id}`,regionData,{withCredentials:true})
  .then(res=>res.data);

  //delete region by id
export const deleteRegion=(id)=>
  axios.delete(`${apiUrl}/status/regions/${id}`,{withCredentials:true})
  .then(res=>res.data);