import axios from 'axios';

const apiUrl = import.meta.env.VITE_API_URL;

export const fetchBookings = async (params) => {
  try {
    const response = await axios.get(`${apiUrl}/bookings/all`, {
      params,
      withCredentials: true
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching bookings:', error);
    throw error;
  }
};

export const fetchMyBookings = async (params) => {
  console.log("params", params);
  
  try {
    // We'll use the same endpoint but add a myBookings flag
    const response = await axios.get(`${apiUrl}/bookings/mybooking`, {
      params: {
        ...params,
        myBookings: true // This flag will be used on the server to filter only user's bookings
      },
      withCredentials: true
    });
    return response.data;
  } catch (error) {
    console.error('Error fetching my bookings:', error);
    throw error;
  }
};

export const updateQueryStatus = async (rowData, queryStatus) => {
  let tableName = '';
  if (rowData.SourceType === 'Visa') {
    tableName = 'VisaProcess';
  } else if (rowData.SourceType === 'Flight') {
    tableName = 'FlightBookings';
  } else if (rowData.SourceType === 'Hotel') {
    tableName = 'HotelBookings';
  } else if (rowData.SourceType === 'TravelPackage') {
    tableName = 'TravelPackageBookings';
  }

  return axios.put(
    `${apiUrl}/bookings/query-status`,
    {
      tableName,
      bookingId: rowData.BookingId,
      queryStatus
    },
    {
      withCredentials: true
    }
  );
};

export const fetchFlightBookingCities = async (bookingId) => {
  return await axios.get(`${apiUrl}/status/flight-booking-cities/${bookingId}`,{
    withCredentials: true
  });
};

export const fetchHotelBookingRooms = async (bookingId) => {
  return await axios.get(`${apiUrl}/status/hotel-booking-rooms/${bookingId}`,{
    withCredentials: true
  });
};

